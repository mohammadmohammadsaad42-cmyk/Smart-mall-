import 'package:json_annotation/json_annotation.dart';

part 'user_model.g.dart';

/// نموذج بيانات المستخدم
@JsonSerializable()
class UserModel {
  final String id;
  final String name;
  final String email;
  final String? phone;
  final String role;
  final String? avatar;
  final bool isActive;
  final DateTime createdAt;
  final DateTime updatedAt;
  
  /// معلومات إضافية حسب نوع المستخدم
  final Map<String, dynamic>? metadata;
  
  UserModel({
    required this.id,
    required this.name,
    required this.email,
    this.phone,
    required this.role,
    this.avatar,
    this.isActive = true,
    required this.createdAt,
    required this.updatedAt,
    this.metadata,
  });
  
  /// إنشاء كائن من JSON
  factory UserModel.fromJson(Map<String, dynamic> json) => _$UserModelFromJson(json);
  
  /// تحويل الكائن إلى JSON
  Map<String, dynamic> toJson() => _$UserModelToJson(this);
  
  /// نسخ الكائن مع تعديل بعض الخصائص
  UserModel copyWith({
    String? id,
    String? name,
    String? email,
    String? phone,
    String? role,
    String? avatar,
    bool? isActive,
    DateTime? createdAt,
    DateTime? updatedAt,
    Map<String, dynamic>? metadata,
  }) {
    return UserModel(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      role: role ?? this.role,
      avatar: avatar ?? this.avatar,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      metadata: metadata ?? this.metadata,
    );
  }
  
  /// الحصول على اسم الدور باللغة العربية
  String get roleNameArabic {
    switch (role.toLowerCase()) {
      case 'admin':
        return 'مدير النظام';
      case 'manager':
        return 'مدير';
      case 'employee':
        return 'موظف';
      case 'tenant':
        return 'مستأجر';
      case 'maintenance':
        return 'فني صيانة';
      case 'security':
        return 'أمن';
      case 'cleaning':
        return 'نظافة';
      default:
        return 'مستخدم';
    }
  }
  
  /// فحص الصلاحيات
  bool hasPermission(String permission) {
    // صلاحيات مدير النظام
    if (role == 'admin') return true;
    
    // صلاحيات المدير
    if (role == 'manager') {
      return ![
        'delete_users',
        'system_settings',
        'backup_restore',
      ].contains(permission);
    }
    
    // صلاحيات الموظف
    if (role == 'employee') {
      return [
        'view_dashboard',
        'view_tenants',
        'view_units',
        'create_maintenance',
        'view_maintenance',
        'update_maintenance',
        'view_reports',
      ].contains(permission);
    }
    
    // صلاحيات المستأجر
    if (role == 'tenant') {
      return [
        'view_dashboard',
        'view_own_unit',
        'create_maintenance',
        'view_own_maintenance',
        'view_own_reports',
      ].contains(permission);
    }
    
    return false;
  }
  
  /// فحص إذا كان المستخدم مدير
  bool get isAdmin => role == 'admin';
  
  /// فحص إذا كان المستخدم مدير أو مدير نظام
  bool get isManagerOrAdmin => ['admin', 'manager'].contains(role);
  
  /// فحص إذا كان المستخدم مستأجر
  bool get isTenant => role == 'tenant';
  
  /// الحصول على الأحرف الأولى من الاسم (لعرض الصورة الرمزية)
  String get initials {
    final nameParts = name.trim().split(' ');
    if (nameParts.length >= 2) {
      return '${nameParts[0][0]}${nameParts[1][0]}'.toUpperCase();
    } else if (nameParts.isNotEmpty) {
      return nameParts[0][0].toUpperCase();
    }
    return 'U';
  }
  
  /// الحصول على URL الصورة الشخصية أو الافتراضية
  String get avatarUrl {
    if (avatar != null && avatar!.isNotEmpty) {
      return avatar!;
    }
    // إرجاع صورة افتراضية بناءً على الأحرف الأولى
    return 'https://ui-avatars.com/api/?name=${Uri.encodeComponent(name)}&background=2E3B42&color=ffffff&size=200';
  }
  
  /// تنسيق تاريخ الإنشاء
  String get formattedCreatedAt {
    final now = DateTime.now();
    final difference = now.difference(createdAt);
    
    if (difference.inDays > 365) {
      return 'منذ ${(difference.inDays / 365).floor()} سنة';
    } else if (difference.inDays > 30) {
      return 'منذ ${(difference.inDays / 30).floor()} شهر';
    } else if (difference.inDays > 0) {
      return 'منذ ${difference.inDays} يوم';
    } else if (difference.inHours > 0) {
      return 'منذ ${difference.inHours} ساعة';
    } else if (difference.inMinutes > 0) {
      return 'منذ ${difference.inMinutes} دقيقة';
    } else {
      return 'الآن';
    }
  }
  
  @override
  String toString() {
    return 'UserModel(id: $id, name: $name, email: $email, role: $role)';
  }
  
  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is UserModel && other.id == id;
  }
  
  @override
  int get hashCode => id.hashCode;
}