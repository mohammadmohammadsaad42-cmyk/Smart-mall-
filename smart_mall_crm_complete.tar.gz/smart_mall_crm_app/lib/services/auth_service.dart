import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import '../utils/app_constants.dart';
import '../models/user_model.dart';

/// خدمة المصادقة والتوثيق
class AuthService {
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();
  
  SharedPreferences? _prefs;
  UserModel? _currentUser;
  String? _authToken;
  
  /// تهيئة الخدمة
  Future<void> initialize() async {
    _prefs = await SharedPreferences.getInstance();
    await _loadUserData();
  }
  
  /// تحميل بيانات المستخدم من التخزين المحلي
  Future<void> _loadUserData() async {
    try {
      _authToken = _prefs?.getString(AppConstants.tokenKey);
      final userJson = _prefs?.getString(AppConstants.userKey);
      
      if (userJson != null) {
        final userMap = jsonDecode(userJson);
        _currentUser = UserModel.fromJson(userMap);
      }
    } catch (e) {
      print('خطأ في تحميل بيانات المستخدم: $e');
    }
  }
  
  /// حفظ بيانات المستخدم في التخزين المحلي
  Future<void> _saveUserData() async {
    try {
      if (_authToken != null) {
        await _prefs?.setString(AppConstants.tokenKey, _authToken!);
      }
      if (_currentUser != null) {
        final userJson = jsonEncode(_currentUser!.toJson());
        await _prefs?.setString(AppConstants.userKey, userJson);
      }
    } catch (e) {
      print('خطأ في حفظ بيانات المستخدم: $e');
    }
  }
  
  /// تسجيل الدخول
  Future<AuthResult> login(String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse('${AppConstants.fullApiUrl}${AppConstants.loginEndpoint}'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: jsonEncode({
          'email': email,
          'password': password,
        }),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        
        _authToken = data['token'];
        _currentUser = UserModel.fromJson(data['user']);
        
        await _saveUserData();
        
        return AuthResult(
          success: true,
          message: AppConstants.loginSuccess,
          user: _currentUser,
        );
      } else {
        final error = jsonDecode(response.body);
        return AuthResult(
          success: false,
          message: error['message'] ?? AppConstants.invalidCredentials,
        );
      }
    } catch (e) {
      return AuthResult(
        success: false,
        message: AppConstants.networkError,
      );
    }
  }
  
  /// تسجيل مستخدم جديد
  Future<AuthResult> register({
    required String name,
    required String email,
    required String password,
    required String phone,
    String? role,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('${AppConstants.fullApiUrl}${AppConstants.registerEndpoint}'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: jsonEncode({
          'name': name,
          'email': email,
          'password': password,
          'phone': phone,
          'role': role ?? AppConstants.employeeRole,
        }),
      );
      
      if (response.statusCode == 201) {
        final data = jsonDecode(response.body);
        
        _authToken = data['token'];
        _currentUser = UserModel.fromJson(data['user']);
        
        await _saveUserData();
        
        return AuthResult(
          success: true,
          message: 'تم إنشاء الحساب بنجاح',
          user: _currentUser,
        );
      } else {
        final error = jsonDecode(response.body);
        return AuthResult(
          success: false,
          message: error['message'] ?? 'فشل في إنشاء الحساب',
        );
      }
    } catch (e) {
      return AuthResult(
        success: false,
        message: AppConstants.networkError,
      );
    }
  }
  
  /// تسجيل الخروج
  Future<void> logout() async {
    try {
      // إرسال طلب تسجيل الخروج للخادم
      if (_authToken != null) {
        await http.post(
          Uri.parse('${AppConstants.fullApiUrl}/auth/logout'),
          headers: {
            'Authorization': 'Bearer $_authToken',
            'Content-Type': 'application/json',
          },
        );
      }
    } catch (e) {
      print('خطأ في تسجيل الخروج من الخادم: $e');
    } finally {
      // مسح البيانات المحلية
      _authToken = null;
      _currentUser = null;
      await _prefs?.remove(AppConstants.tokenKey);
      await _prefs?.remove(AppConstants.userKey);
    }
  }
  
  /// فحص حالة تسجيل الدخول
  Future<bool> isLoggedIn() async {
    if (_prefs == null) {
      await initialize();
    }
    
    final token = _prefs?.getString(AppConstants.tokenKey);
    return token != null && token.isNotEmpty;
  }
  
  /// الحصول على رمز التوثيق
  String? get authToken => _authToken;
  
  /// الحصول على المستخدم الحالي
  UserModel? get currentUser => _currentUser;
  
  /// تحديث بيانات المستخدم
  Future<AuthResult> updateProfile({
    String? name,
    String? phone,
    String? avatar,
  }) async {
    try {
      if (_authToken == null) {
        return AuthResult(
          success: false,
          message: AppConstants.loginRequired,
        );
      }
      
      final response = await http.put(
        Uri.parse('${AppConstants.fullApiUrl}${AppConstants.profileEndpoint}'),
        headers: {
          'Authorization': 'Bearer $_authToken',
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: jsonEncode({
          if (name != null) 'name': name,
          if (phone != null) 'phone': phone,
          if (avatar != null) 'avatar': avatar,
        }),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _currentUser = UserModel.fromJson(data['user']);
        await _saveUserData();
        
        return AuthResult(
          success: true,
          message: AppConstants.updateSuccess,
          user: _currentUser,
        );
      } else {
        final error = jsonDecode(response.body);
        return AuthResult(
          success: false,
          message: error['message'] ?? 'فشل في تحديث البيانات',
        );
      }
    } catch (e) {
      return AuthResult(
        success: false,
        message: AppConstants.networkError,
      );
    }
  }
  
  /// تغيير كلمة المرور
  Future<AuthResult> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    try {
      if (_authToken == null) {
        return AuthResult(
          success: false,
          message: AppConstants.loginRequired,
        );
      }
      
      final response = await http.put(
        Uri.parse('${AppConstants.fullApiUrl}/auth/change-password'),
        headers: {
          'Authorization': 'Bearer $_authToken',
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: jsonEncode({
          'current_password': currentPassword,
          'new_password': newPassword,
        }),
      );
      
      if (response.statusCode == 200) {
        return AuthResult(
          success: true,
          message: 'تم تغيير كلمة المرور بنجاح',
        );
      } else {
        final error = jsonDecode(response.body);
        return AuthResult(
          success: false,
          message: error['message'] ?? 'فشل في تغيير كلمة المرور',
        );
      }
    } catch (e) {
      return AuthResult(
        success: false,
        message: AppConstants.networkError,
      );
    }
  }
  
  /// التحقق من صحة الرمز المميز
  Future<bool> validateToken() async {
    try {
      if (_authToken == null) return false;
      
      final response = await http.get(
        Uri.parse('${AppConstants.fullApiUrl}/auth/validate'),
        headers: {
          'Authorization': 'Bearer $_authToken',
          'Accept': 'application/json',
        },
      );
      
      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }
  
  /// الحصول على headers للطلبات المصادق عليها
  Map<String, String> getAuthHeaders() {
    return {
      'Authorization': 'Bearer $_authToken',
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
  }
}

/// نتيجة عملية المصادقة
class AuthResult {
  final bool success;
  final String message;
  final UserModel? user;
  
  AuthResult({
    required this.success,
    required this.message,
    this.user,
  });
}