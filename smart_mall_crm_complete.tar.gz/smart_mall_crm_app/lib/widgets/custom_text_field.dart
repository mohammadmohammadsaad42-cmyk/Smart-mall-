import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../utils/app_constants.dart';

/// حقل نص مخصص قابل لإعادة الاستخدام
class CustomTextField extends StatefulWidget {
  final TextEditingController? controller;
  final String? label;
  final String? hint;
  final IconData? prefixIcon;
  final Widget? suffixIcon;
  final bool obscureText;
  final TextInputType keyboardType;
  final TextInputAction textInputAction;
  final int? maxLines;
  final int? maxLength;
  final bool enabled;
  final bool readOnly;
  final String? Function(String?)? validator;
  final void Function(String)? onChanged;
  final void Function(String)? onFieldSubmitted;
  final void Function()? onTap;
  final List<TextInputFormatter>? inputFormatters;
  final FocusNode? focusNode;
  final TextDirection? textDirection;
  final TextAlign textAlign;
  final bool showCounter;
  final String? errorText;
  final String? helperText;
  
  const CustomTextField({
    Key? key,
    this.controller,
    this.label,
    this.hint,
    this.prefixIcon,
    this.suffixIcon,
    this.obscureText = false,
    this.keyboardType = TextInputType.text,
    this.textInputAction = TextInputAction.next,
    this.maxLines = 1,
    this.maxLength,
    this.enabled = true,
    this.readOnly = false,
    this.validator,
    this.onChanged,
    this.onFieldSubmitted,
    this.onTap,
    this.inputFormatters,
    this.focusNode,
    this.textDirection,
    this.textAlign = TextAlign.start,
    this.showCounter = false,
    this.errorText,
    this.helperText,
  }) : super(key: key);
  
  @override
  State<CustomTextField> createState() => _CustomTextFieldState();
}

class _CustomTextFieldState extends State<CustomTextField> 
    with SingleTickerProviderStateMixin {
  
  late AnimationController _animationController;
  late Animation<double> _animation;
  bool _isFocused = false;
  bool _hasError = false;
  
  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
    );
    _animation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
  }
  
  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
  
  void _onFocusChange(bool hasFocus) {
    setState(() {
      _isFocused = hasFocus;
    });
    
    if (hasFocus) {
      _animationController.forward();
    } else {
      _animationController.reverse();
    }
  }
  
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // تسمية الحقل
        if (widget.label != null) ...[
          AnimatedBuilder(
            animation: _animation,
            builder: (context, child) {
              return Text(
                widget.label!,
                style: theme.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: _hasError 
                    ? theme.colorScheme.error
                    : _isFocused 
                      ? theme.primaryColor
                      : theme.textTheme.bodyMedium?.color,
                ),
              );
            },
          ),
          const SizedBox(height: AppConstants.paddingSmall / 2),
        ],
        
        // حقل النص
        Focus(
          onFocusChange: _onFocusChange,
          child: AnimatedBuilder(
            animation: _animation,
            builder: (context, child) {
              return AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(
                    AppConstants.borderRadiusMedium,
                  ),
                  boxShadow: _isFocused && !_hasError
                    ? [
                        BoxShadow(
                          color: theme.primaryColor.withOpacity(0.3),
                          blurRadius: 8,
                          offset: const Offset(0, 4),
                        )
                      ]
                    : [],
                ),
                child: TextFormField(
                  controller: widget.controller,
                  focusNode: widget.focusNode,
                  obscureText: widget.obscureText,
                  keyboardType: widget.keyboardType,
                  textInputAction: widget.textInputAction,
                  maxLines: widget.maxLines,
                  maxLength: widget.maxLength,
                  enabled: widget.enabled,
                  readOnly: widget.readOnly,
                  textAlign: widget.textAlign,
                  textDirection: widget.textDirection,
                  inputFormatters: widget.inputFormatters,
                  style: theme.textTheme.bodyLarge?.copyWith(
                    color: widget.enabled 
                      ? theme.textTheme.bodyLarge?.color
                      : theme.disabledColor,
                  ),
                  decoration: InputDecoration(
                    hintText: widget.hint,
                    hintStyle: theme.inputDecorationTheme.hintStyle,
                    prefixIcon: widget.prefixIcon != null 
                      ? Icon(
                          widget.prefixIcon,
                          color: _hasError 
                            ? theme.colorScheme.error
                            : _isFocused 
                              ? theme.primaryColor
                              : theme.iconTheme.color,
                        )
                      : null,
                    suffixIcon: widget.suffixIcon,
                    errorText: widget.errorText,
                    helperText: widget.helperText,
                    counterText: widget.showCounter ? null : '',
                    filled: true,
                    fillColor: widget.enabled 
                      ? theme.inputDecorationTheme.fillColor
                      : theme.disabledColor.withOpacity(0.1),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(
                        AppConstants.borderRadiusMedium,
                      ),
                      borderSide: BorderSide(
                        color: theme.dividerColor,
                        width: 1,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(
                        AppConstants.borderRadiusMedium,
                      ),
                      borderSide: BorderSide(
                        color: theme.dividerColor,
                        width: 1,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(
                        AppConstants.borderRadiusMedium,
                      ),
                      borderSide: BorderSide(
                        color: theme.primaryColor,
                        width: 2,
                      ),
                    ),
                    errorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(
                        AppConstants.borderRadiusMedium,
                      ),
                      borderSide: BorderSide(
                        color: theme.colorScheme.error,
                        width: 2,
                      ),
                    ),
                    focusedErrorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(
                        AppConstants.borderRadiusMedium,
                      ),
                      borderSide: BorderSide(
                        color: theme.colorScheme.error,
                        width: 2,
                      ),
                    ),
                    disabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(
                        AppConstants.borderRadiusMedium,
                      ),
                      borderSide: BorderSide(
                        color: theme.disabledColor.withOpacity(0.3),
                        width: 1,
                      ),
                    ),
                  ),
                  validator: (value) {
                    final result = widget.validator?.call(value);
                    setState(() {
                      _hasError = result != null;
                    });
                    return result;
                  },
                  onChanged: widget.onChanged,
                  onFieldSubmitted: widget.onFieldSubmitted,
                  onTap: widget.onTap,
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

/// حقل نص للبحث
class SearchTextField extends StatelessWidget {
  final TextEditingController? controller;
  final String? hint;
  final void Function(String)? onChanged;
  final void Function()? onClear;
  final bool showClearButton;
  
  const SearchTextField({
    Key? key,
    this.controller,
    this.hint,
    this.onChanged,
    this.onClear,
    this.showClearButton = true,
  }) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    return CustomTextField(
      controller: controller,
      hint: hint ?? 'البحث...',
      prefixIcon: Icons.search_outlined,
      suffixIcon: showClearButton && 
        controller != null && 
        controller!.text.isNotEmpty
          ? IconButton(
              icon: const Icon(Icons.clear_outlined),
              onPressed: () {
                controller!.clear();
                onClear?.call();
              },
            )
          : null,
      onChanged: onChanged,
      textInputAction: TextInputAction.search,
    );
  }
}

/// حقل نص للأرقام
class NumberTextField extends StatelessWidget {
  final TextEditingController? controller;
  final String? label;
  final String? hint;
  final double? min;
  final double? max;
  final int? decimalPlaces;
  final String? Function(String?)? validator;
  final void Function(double?)? onChanged;
  final bool allowNegative;
  
  const NumberTextField({
    Key? key,
    this.controller,
    this.label,
    this.hint,
    this.min,
    this.max,
    this.decimalPlaces,
    this.validator,
    this.onChanged,
    this.allowNegative = false,
  }) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    return CustomTextField(
      controller: controller,
      label: label,
      hint: hint,
      keyboardType: TextInputType.numberWithOptions(
        decimal: decimalPlaces != null && decimalPlaces! > 0,
        signed: allowNegative,
      ),
      inputFormatters: [
        FilteringTextInputFormatter.allow(
          RegExp(allowNegative 
            ? r'^-?\d*\.?\d*' 
            : r'^\d*\.?\d*'
          ),
        ),
      ],
      validator: (value) {
        if (validator != null) {
          final result = validator!(value);
          if (result != null) return result;
        }
        
        if (value != null && value.isNotEmpty) {
          final number = double.tryParse(value);
          if (number == null) {
            return 'يرجى إدخال رقم صالح';
          }
          
          if (min != null && number < min!) {
            return 'القيمة يجب أن تكون أكبر من أو تساوي $min';
          }
          
          if (max != null && number > max!) {
            return 'القيمة يجب أن تكون أصغر من أو تساوي $max';
          }
        }
        
        return null;
      },
      onChanged: (value) {
        final number = double.tryParse(value);
        onChanged?.call(number);
      },
    );
  }
}