import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import '../utils/app_constants.dart';

/// تغطية التحميل للشاشات
class LoadingOverlay extends StatelessWidget {
  final bool isLoading;
  final Widget child;
  final String? loadingText;
  final Color? backgroundColor;
  final Color? spinnerColor;
  final double opacity;
  
  const LoadingOverlay({
    Key? key,
    required this.isLoading,
    required this.child,
    this.loadingText,
    this.backgroundColor,
    this.spinnerColor,
    this.opacity = 0.8,
  }) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        child,
        if (isLoading)
          Container(
            color: (backgroundColor ?? Colors.black).withOpacity(opacity),
            child: Center(
              child: Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(
                    AppConstants.borderRadiusLarge,
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(AppConstants.paddingLarge),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SpinKitFadingCircle(
                        color: spinnerColor ?? Theme.of(context).primaryColor,
                        size: 50,
                      ),
                      if (loadingText != null) ...[
                        const SizedBox(height: AppConstants.paddingMedium),
                        Text(
                          loadingText!,
                          style: Theme.of(context).textTheme.bodyMedium,
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

/// مؤشر تحميل مخصص
class CustomLoadingIndicator extends StatelessWidget {
  final String? message;
  final Color? color;
  final double size;
  final LoadingType type;
  
  const CustomLoadingIndicator({
    Key? key,
    this.message,
    this.color,
    this.size = 40,
    this.type = LoadingType.circle,
  }) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final indicatorColor = color ?? theme.primaryColor;
    
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildLoadingWidget(indicatorColor),
          if (message != null) ...[
            const SizedBox(height: AppConstants.paddingMedium),
            Text(
              message!,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.textTheme.bodyMedium?.color?.withOpacity(0.7),
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ],
      ),
    );
  }
  
  Widget _buildLoadingWidget(Color color) {
    switch (type) {
      case LoadingType.circle:
        return SpinKitFadingCircle(
          color: color,
          size: size,
        );
      case LoadingType.dots:
        return SpinKitThreeBounce(
          color: color,
          size: size * 0.6,
        );
      case LoadingType.wave:
        return SpinKitWave(
          color: color,
          size: size * 0.8,
        );
      case LoadingType.pulse:
        return SpinKitPulse(
          color: color,
          size: size,
        );
      case LoadingType.spinner:
        return SpinKitSpinningCircle(
          color: color,
          size: size,
        );
    }
  }
}

/// أنواع مؤشرات التحميل
enum LoadingType {
  circle,
  dots,
  wave,
  pulse,
  spinner,
}

/// بطاقة تحميل للقوائم
class LoadingCard extends StatelessWidget {
  final double? height;
  final double? width;
  final EdgeInsetsGeometry? margin;
  final BorderRadius? borderRadius;
  
  const LoadingCard({
    Key? key,
    this.height,
    this.width,
    this.margin,
    this.borderRadius,
  }) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    return Container(
      height: height ?? 120,
      width: width,
      margin: margin ?? const EdgeInsets.all(AppConstants.paddingSmall),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: borderRadius ?? 
          BorderRadius.circular(AppConstants.borderRadiusLarge),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: const Center(
        child: CustomLoadingIndicator(
          type: LoadingType.dots,
          size: 30,
        ),
      ),
    );
  }
}

/// شيمر للتحميل
class ShimmerLoading extends StatefulWidget {
  final Widget child;
  final bool isLoading;
  final Color? baseColor;
  final Color? highlightColor;
  final Duration duration;
  
  const ShimmerLoading({
    Key? key,
    required this.child,
    this.isLoading = true,
    this.baseColor,
    this.highlightColor,
    this.duration = const Duration(milliseconds: 1500),
  }) : super(key: key);
  
  @override
  State<ShimmerLoading> createState() => _ShimmerLoadingState();
}

class _ShimmerLoadingState extends State<ShimmerLoading>
    with SingleTickerProviderStateMixin {
  
  late AnimationController _animationController;
  late Animation<double> _animation;
  
  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: widget.duration,
      vsync: this,
    );
    _animation = Tween<double>(
      begin: -2.0,
      end: 2.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOutSine,
    ));
    
    if (widget.isLoading) {
      _animationController.repeat();
    }
  }
  
  @override
  void didUpdateWidget(ShimmerLoading oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isLoading && !oldWidget.isLoading) {
      _animationController.repeat();
    } else if (!widget.isLoading && oldWidget.isLoading) {
      _animationController.stop();
    }
  }
  
  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    if (!widget.isLoading) {
      return widget.child;
    }
    
    final theme = Theme.of(context);
    final baseColor = widget.baseColor ?? 
      (theme.brightness == Brightness.light 
        ? Colors.grey[300]! 
        : Colors.grey[700]!);
    final highlightColor = widget.highlightColor ?? 
      (theme.brightness == Brightness.light 
        ? Colors.grey[100]! 
        : Colors.grey[500]!);
    
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, child) {
        return ShaderMask(
          shaderCallback: (Rect bounds) {
            return LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: [
                baseColor,
                highlightColor,
                baseColor,
              ],
              stops: const [0.0, 0.5, 1.0],
              transform: GradientRotation(_animation.value),
            ).createShader(bounds);
          },
          child: widget.child,
        );
      },
    );
  }
}

/// قائمة شيمر للتحميل
class ShimmerList extends StatelessWidget {
  final int itemCount;
  final double itemHeight;
  final EdgeInsetsGeometry? padding;
  final Widget Function(BuildContext, int)? separatorBuilder;
  
  const ShimmerList({
    Key? key,
    this.itemCount = 5,
    this.itemHeight = 80,
    this.padding,
    this.separatorBuilder,
  }) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: padding,
      itemCount: itemCount,
      separatorBuilder: separatorBuilder ?? 
        (context, index) => const SizedBox(height: AppConstants.paddingSmall),
      itemBuilder: (context, index) {
        return ShimmerLoading(
          child: Container(
            height: itemHeight,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(
                AppConstants.borderRadiusMedium,
              ),
            ),
          ),
        );
      },
    );
  }
}