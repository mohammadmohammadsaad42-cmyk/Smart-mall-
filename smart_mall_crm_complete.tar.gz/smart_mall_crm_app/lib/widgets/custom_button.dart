import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import '../utils/app_constants.dart';

/// زر مخصص قابل لإعادة الاستخدام
class CustomButton extends StatefulWidget {
  final String text;
  final VoidCallback? onPressed;
  final bool isLoading;
  final bool isEnabled;
  final IconData? icon;
  final Color? backgroundColor;
  final Color? textColor;
  final double? width;
  final double? height;
  final EdgeInsetsGeometry? padding;
  final BorderRadius? borderRadius;
  final ButtonType type;
  final ButtonSize size;
  
  const CustomButton({
    Key? key,
    required this.text,
    this.onPressed,
    this.isLoading = false,
    this.isEnabled = true,
    this.icon,
    this.backgroundColor,
    this.textColor,
    this.width,
    this.height,
    this.padding,
    this.borderRadius,
    this.type = ButtonType.elevated,
    this.size = ButtonSize.medium,
  }) : super(key: key);
  
  @override
  State<CustomButton> createState() => _CustomButtonState();
}

class _CustomButtonState extends State<CustomButton> 
    with SingleTickerProviderStateMixin {
  
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  bool _isPressed = false;
  
  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 100),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 0.95,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
  }
  
  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
  
  void _onTapDown(TapDownDetails details) {
    setState(() => _isPressed = true);
    _animationController.forward();
  }
  
  void _onTapUp(TapUpDetails details) {
    setState(() => _isPressed = false);
    _animationController.reverse();
  }
  
  void _onTapCancel() {
    setState(() => _isPressed = false);
    _animationController.reverse();
  }
  
  double get _buttonHeight {
    switch (widget.size) {
      case ButtonSize.small:
        return widget.height ?? 40;
      case ButtonSize.medium:
        return widget.height ?? AppConstants.buttonHeight;
      case ButtonSize.large:
        return widget.height ?? 56;
    }
  }
  
  double get _fontSize {
    switch (widget.size) {
      case ButtonSize.small:
        return AppConstants.fontSizeSmall;
      case ButtonSize.medium:
        return AppConstants.fontSizeMedium;
      case ButtonSize.large:
        return AppConstants.fontSizeLarge;
    }
  }
  
  EdgeInsetsGeometry get _buttonPadding {
    if (widget.padding != null) return widget.padding!;
    
    switch (widget.size) {
      case ButtonSize.small:
        return const EdgeInsets.symmetric(horizontal: 16, vertical: 8);
      case ButtonSize.medium:
        return const EdgeInsets.symmetric(horizontal: 24, vertical: 12);
      case ButtonSize.large:
        return const EdgeInsets.symmetric(horizontal: 32, vertical: 16);
    }
  }
  
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isEnabled = widget.isEnabled && !widget.isLoading && widget.onPressed != null;
    
    return AnimatedBuilder(
      animation: _scaleAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _scaleAnimation.value,
          child: GestureDetector(
            onTapDown: isEnabled ? _onTapDown : null,
            onTapUp: isEnabled ? _onTapUp : null,
            onTapCancel: isEnabled ? _onTapCancel : null,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: widget.width,
              height: _buttonHeight,
              decoration: BoxDecoration(
                borderRadius: widget.borderRadius ?? 
                  BorderRadius.circular(AppConstants.borderRadiusMedium),
                boxShadow: widget.type == ButtonType.elevated && isEnabled
                  ? [
                      BoxShadow(
                        color: (widget.backgroundColor ?? theme.primaryColor)
                          .withOpacity(0.3),
                        blurRadius: _isPressed ? 4 : 8,
                        offset: Offset(0, _isPressed ? 2 : 4),
                      ),
                    ]
                  : [],
              ),
              child: _buildButton(context, theme, isEnabled),
            ),
          ),
        );
      },
    );
  }
  
  Widget _buildButton(BuildContext context, ThemeData theme, bool isEnabled) {
    switch (widget.type) {
      case ButtonType.elevated:
        return _buildElevatedButton(theme, isEnabled);
      case ButtonType.outlined:
        return _buildOutlinedButton(theme, isEnabled);
      case ButtonType.text:
        return _buildTextButton(theme, isEnabled);
      case ButtonType.icon:
        return _buildIconButton(theme, isEnabled);
    }
  }
  
  Widget _buildElevatedButton(ThemeData theme, bool isEnabled) {
    return ElevatedButton(
      onPressed: isEnabled ? widget.onPressed : null,
      style: ElevatedButton.styleFrom(
        backgroundColor: widget.backgroundColor ?? theme.primaryColor,
        foregroundColor: widget.textColor ?? Colors.white,
        minimumSize: Size(widget.width ?? double.infinity, _buttonHeight),
        padding: _buttonPadding,
        shape: RoundedRectangleBorder(
          borderRadius: widget.borderRadius ?? 
            BorderRadius.circular(AppConstants.borderRadiusMedium),
        ),
        elevation: _isPressed ? 2 : 4,
      ),
      child: _buildButtonContent(),
    );
  }
  
  Widget _buildOutlinedButton(ThemeData theme, bool isEnabled) {
    final borderColor = widget.backgroundColor ?? theme.primaryColor;
    return OutlinedButton(
      onPressed: isEnabled ? widget.onPressed : null,
      style: OutlinedButton.styleFrom(
        foregroundColor: widget.textColor ?? borderColor,
        minimumSize: Size(widget.width ?? double.infinity, _buttonHeight),
        padding: _buttonPadding,
        side: BorderSide(
          color: isEnabled ? borderColor : theme.disabledColor,
          width: 2,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: widget.borderRadius ?? 
            BorderRadius.circular(AppConstants.borderRadiusMedium),
        ),
      ),
      child: _buildButtonContent(),
    );
  }
  
  Widget _buildTextButton(ThemeData theme, bool isEnabled) {
    return TextButton(
      onPressed: isEnabled ? widget.onPressed : null,
      style: TextButton.styleFrom(
        foregroundColor: widget.textColor ?? 
          (widget.backgroundColor ?? theme.primaryColor),
        minimumSize: Size(widget.width ?? 0, _buttonHeight),
        padding: _buttonPadding,
        shape: RoundedRectangleBorder(
          borderRadius: widget.borderRadius ?? 
            BorderRadius.circular(AppConstants.borderRadiusMedium),
        ),
      ),
      child: _buildButtonContent(),
    );
  }
  
  Widget _buildIconButton(ThemeData theme, bool isEnabled) {
    return Material(
      color: widget.backgroundColor ?? theme.primaryColor,
      borderRadius: widget.borderRadius ?? 
        BorderRadius.circular(AppConstants.borderRadiusMedium),
      child: InkWell(
        onTap: isEnabled ? widget.onPressed : null,
        borderRadius: widget.borderRadius ?? 
          BorderRadius.circular(AppConstants.borderRadiusMedium),
        child: Container(
          width: widget.width ?? _buttonHeight,
          height: _buttonHeight,
          padding: _buttonPadding,
          child: _buildButtonContent(),
        ),
      ),
    );
  }
  
  Widget _buildButtonContent() {
    if (widget.isLoading) {
      return SpinKitThreeBounce(
        color: widget.textColor ?? 
          (widget.type == ButtonType.elevated ? Colors.white : null),
        size: _fontSize,
      );
    }
    
    if (widget.icon != null && widget.type != ButtonType.icon) {
      return Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            widget.icon,
            size: _fontSize + 4,
          ),
          const SizedBox(width: AppConstants.paddingSmall),
          Text(
            widget.text,
            style: TextStyle(
              fontSize: _fontSize,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      );
    }
    
    if (widget.type == ButtonType.icon) {
      return Icon(
        widget.icon ?? Icons.touch_app,
        size: _fontSize + 8,
        color: widget.textColor ?? Colors.white,
      );
    }
    
    return Text(
      widget.text,
      style: TextStyle(
        fontSize: _fontSize,
        fontWeight: FontWeight.w600,
      ),
      textAlign: TextAlign.center,
    );
  }
}

/// أنواع الأزرار
enum ButtonType {
  elevated,
  outlined,
  text,
  icon,
}

/// أحجام الأزرار
enum ButtonSize {
  small,
  medium,
  large,
}

/// زر عائم للإجراءات السريعة
class FloatingActionCustomButton extends StatelessWidget {
  final VoidCallback onPressed;
  final IconData icon;
  final String? tooltip;
  final Color? backgroundColor;
  final Color? iconColor;
  final bool mini;
  
  const FloatingActionCustomButton({
    Key? key,
    required this.onPressed,
    this.icon = Icons.add,
    this.tooltip,
    this.backgroundColor,
    this.iconColor,
    this.mini = false,
  }) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      onPressed: onPressed,
      backgroundColor: backgroundColor,
      tooltip: tooltip,
      mini: mini,
      child: Icon(
        icon,
        color: iconColor,
      ),
    );
  }
}

/// مجموعة أزرار للاختيار
class ButtonGroup extends StatelessWidget {
  final List<String> options;
  final String? selectedOption;
  final void Function(String) onSelected;
  final ButtonSize size;
  final bool allowMultipleSelection;
  final List<String>? selectedOptions;
  final void Function(List<String>)? onMultipleSelected;
  
  const ButtonGroup({
    Key? key,
    required this.options,
    this.selectedOption,
    required this.onSelected,
    this.size = ButtonSize.medium,
    this.allowMultipleSelection = false,
    this.selectedOptions,
    this.onMultipleSelected,
  }) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: AppConstants.paddingSmall,
      runSpacing: AppConstants.paddingSmall,
      children: options.map((option) {
        final isSelected = allowMultipleSelection
          ? selectedOptions?.contains(option) ?? false
          : selectedOption == option;
        
        return CustomButton(
          text: option,
          type: isSelected ? ButtonType.elevated : ButtonType.outlined,
          size: size,
          width: null,
          onPressed: () {
            if (allowMultipleSelection) {
              final currentSelection = List<String>.from(selectedOptions ?? []);
              if (currentSelection.contains(option)) {
                currentSelection.remove(option);
              } else {
                currentSelection.add(option);
              }
              onMultipleSelected?.call(currentSelection);
            } else {
              onSelected(option);
            }
          },
        );
      }).toList(),
    );
  }
}