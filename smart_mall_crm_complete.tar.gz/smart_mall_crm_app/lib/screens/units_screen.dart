import 'package:flutter/material.dart';

class UnitsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الوحدات التجارية')),
      body: const Center(child: Text('شاشة الوحدات التجارية - قيد التطوير')),
    );
  }
}