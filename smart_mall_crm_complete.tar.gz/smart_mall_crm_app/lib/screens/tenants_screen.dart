import 'package:flutter/material.dart';

class TenantsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المستأجرون')),
      body: const Center(child: Text('شاشة المستأجرين - قيد التطوير')),
    );
  }
}