import 'package:flutter/material.dart';

class MaintenanceScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الصيانة')),
      body: const Center(child: Text('شاشة الصيانة - قيد التطوير')),
    );
  }
}