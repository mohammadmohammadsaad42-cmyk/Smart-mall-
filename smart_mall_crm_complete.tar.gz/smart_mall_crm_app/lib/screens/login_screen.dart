import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../utils/app_constants.dart';
import '../services/auth_service.dart';
import '../widgets/custom_text_field.dart';
import '../widgets/custom_button.dart';
import '../widgets/loading_overlay.dart';

/// شاشة تسجيل الدخول
class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> 
    with SingleTickerProviderStateMixin {
  
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _authService = AuthService();
  
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  
  bool _isLoading = false;
  bool _obscurePassword = true;
  bool _rememberMe = false;
  
  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _loadSavedCredentials();
  }
  
  /// تهيئة الرسوم المتحركة
  void _initializeAnimations() {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: const Interval(0.3, 1.0, curve: Curves.easeInOut),
    ));
    
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: const Interval(0.3, 1.0, curve: Curves.easeOutBack),
    ));
    
    _animationController.forward();
  }
  
  /// تحميل بيانات الدخول المحفوظة
  Future<void> _loadSavedCredentials() async {
    // يمكن تنفيذ هذه الوظيفة لتحميل بيانات محفوظة
  }
  
  /// تسجيل الدخول
  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    
    setState(() => _isLoading = true);
    
    try {
      final result = await _authService.login(
        _emailController.text.trim(),
        _passwordController.text,
      );
      
      if (result.success) {
        _showMessage(result.message, isError: false);
        Navigator.of(context).pushReplacementNamed('/dashboard');
      } else {
        _showMessage(result.message, isError: true);
      }
    } catch (e) {
      _showMessage(AppConstants.unknownError, isError: true);
    } finally {
      setState(() => _isLoading = false);
    }
  }
  
  /// عرض رسالة للمستخدم
  void _showMessage(String message, {bool isError = true}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError 
          ? Theme.of(context).colorScheme.error
          : Colors.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppConstants.borderRadiusMedium),
        ),
      ),
    );
  }
  
  @override
  void dispose() {
    _animationController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LoadingOverlay(
        isLoading: _isLoading,
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [
                Theme.of(context).primaryColor,
                Theme.of(context).primaryColor.withOpacity(0.8),
              ],
            ),
          ),
          child: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(AppConstants.paddingLarge),
                child: AnimatedBuilder(
                  animation: _animationController,
                  builder: (context, child) {
                    return FadeTransition(
                      opacity: _fadeAnimation,
                      child: SlideTransition(
                        position: _slideAnimation,
                        child: Card(
                          elevation: 8,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(
                              AppConstants.borderRadiusLarge,
                            ),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(AppConstants.paddingLarge),
                            child: Form(
                              key: _formKey,
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  // شعار التطبيق
                                  Container(
                                    width: 80,
                                    height: 80,
                                    decoration: BoxDecoration(
                                      color: Theme.of(context).primaryColor,
                                      shape: BoxShape.circle,
                                    ),
                                    child: const Icon(
                                      Icons.business,
                                      size: 40,
                                      color: Colors.white,
                                    ),
                                  ),
                                  
                                  const SizedBox(height: AppConstants.paddingMedium),
                                  
                                  // عنوان الشاشة
                                  Text(
                                    'تسجيل الدخول',
                                    style: Theme.of(context).textTheme.displayLarge?.copyWith(
                                      fontSize: 28,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  
                                  const SizedBox(height: AppConstants.paddingSmall),
                                  
                                  Text(
                                    'مرحباً بك في ${AppConstants.appName}',
                                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                  
                                  const SizedBox(height: AppConstants.paddingLarge),
                                  
                                  // حقل البريد الإلكتروني
                                  CustomTextField(
                                    controller: _emailController,
                                    label: 'البريد الإلكتروني',
                                    hint: 'أدخل بريدك الإلكتروني',
                                    prefixIcon: Icons.email_outlined,
                                    keyboardType: TextInputType.emailAddress,
                                    textInputAction: TextInputAction.next,
                                    validator: (value) {
                                      if (value == null || value.isEmpty) {
                                        return 'البريد الإلكتروني مطلوب';
                                      }
                                      if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                                        return 'البريد الإلكتروني غير صالح';
                                      }
                                      return null;
                                    },
                                  ),
                                  
                                  const SizedBox(height: AppConstants.paddingMedium),
                                  
                                  // حقل كلمة المرور
                                  CustomTextField(
                                    controller: _passwordController,
                                    label: 'كلمة المرور',
                                    hint: 'أدخل كلمة المرور',
                                    prefixIcon: Icons.lock_outlined,
                                    obscureText: _obscurePassword,
                                    textInputAction: TextInputAction.done,
                                    suffixIcon: IconButton(
                                      icon: Icon(
                                        _obscurePassword 
                                          ? Icons.visibility_outlined
                                          : Icons.visibility_off_outlined,
                                      ),
                                      onPressed: () {
                                        setState(() {
                                          _obscurePassword = !_obscurePassword;
                                        });
                                      },
                                    ),
                                    validator: (value) {
                                      if (value == null || value.isEmpty) {
                                        return 'كلمة المرور مطلوبة';
                                      }
                                      if (value.length < AppConstants.minPasswordLength) {
                                        return 'كلمة المرور قصيرة جدًا';
                                      }
                                      return null;
                                    },
                                    onFieldSubmitted: (_) => _login(),
                                  ),
                                  
                                  const SizedBox(height: AppConstants.paddingSmall),
                                  
                                  // تذكرني و نسيت كلمة المرور
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          Checkbox(
                                            value: _rememberMe,
                                            onChanged: (value) {
                                              setState(() {
                                                _rememberMe = value ?? false;
                                              });
                                            },
                                          ),
                                          const Text('تذكرني'),
                                        ],
                                      ),
                                      TextButton(
                                        onPressed: () {
                                          // تنفيذ نسيت كلمة المرور
                                        },
                                        child: const Text('نسيت كلمة المرور؟'),
                                      ),
                                    ],
                                  ),
                                  
                                  const SizedBox(height: AppConstants.paddingLarge),
                                  
                                  // زر تسجيل الدخول
                                  CustomButton(
                                    text: 'تسجيل الدخول',
                                    onPressed: _login,
                                    isLoading: _isLoading,
                                  ),
                                  
                                  const SizedBox(height: AppConstants.paddingMedium),
                                  
                                  // خط فاصل
                                  Row(
                                    children: [
                                      Expanded(child: Divider()),
                                      Padding(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: AppConstants.paddingMedium,
                                        ),
                                        child: Text(
                                          'أو',
                                          style: TextStyle(color: Colors.grey[600]),
                                        ),
                                      ),
                                      Expanded(child: Divider()),
                                    ],
                                  ),
                                  
                                  const SizedBox(height: AppConstants.paddingMedium),
                                  
                                  // تسجيل الدخول كضيف (للاختبار)
                                  OutlinedButton.icon(
                                    onPressed: () {
                                      _emailController.text = 'admin@smartmall.com';
                                      _passwordController.text = 'admin123';
                                    },
                                    icon: const Icon(Icons.person_outline),
                                    label: const Text('تسجيل دخول تجريبي'),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}