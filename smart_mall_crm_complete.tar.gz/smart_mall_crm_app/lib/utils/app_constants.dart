/// ثوابت التطبيق الأساسية
class AppConstants {
  // معلومات التطبيق
  static const String appName = 'Smart Mall CRM';
  static const String appVersion = '1.0.0';
  static const String appDescription = 'نظام إدارة المولات الذكية';
  
  // API URLs
  static const String baseUrl = 'https://api.smartmall.com';
  static const String apiVersion = '/api/v1';
  static const String fullApiUrl = '$baseUrl$apiVersion';
  
  // Endpoints
  static const String loginEndpoint = '/auth/login';
  static const String registerEndpoint = '/auth/register';
  static const String profileEndpoint = '/user/profile';
  static const String tenantsEndpoint = '/tenants';
  static const String unitsEndpoint = '/units';
  static const String maintenanceEndpoint = '/maintenance';
  static const String reportsEndpoint = '/reports';
  
  // مفاتيح التخزين المحلي
  static const String tokenKey = 'auth_token';
  static const String userKey = 'user_data';
  static const String settingsKey = 'app_settings';
  static const String languageKey = 'selected_language';
  
  // الألوان
  static const int primaryColorValue = 0xFF2E3B42;
  static const int secondaryColorValue = 0xFF3498DB;
  static const int accentColorValue = 0xFFE74C3C;
  static const int successColorValue = 0xFF27AE60;
  static const int warningColorValue = 0xFFF39C12;
  static const int errorColorValue = 0xFFE74C3C;
  
  // أحجام الخط
  static const double fontSizeSmall = 12.0;
  static const double fontSizeMedium = 16.0;
  static const double fontSizeLarge = 20.0;
  static const double fontSizeXLarge = 24.0;
  
  // المسافات
  static const double paddingSmall = 8.0;
  static const double paddingMedium = 16.0;
  static const double paddingLarge = 24.0;
  static const double paddingXLarge = 32.0;
  
  // الحدود
  static const double borderRadiusSmall = 4.0;
  static const double borderRadiusMedium = 8.0;
  static const double borderRadiusLarge = 12.0;
  static const double borderRadiusXLarge = 16.0;
  
  // أحجام الأيقونات
  static const double iconSizeSmall = 16.0;
  static const double iconSizeMedium = 24.0;
  static const double iconSizeLarge = 32.0;
  static const double iconSizeXLarge = 48.0;
  
  // ارتفاعات العناصر
  static const double buttonHeight = 48.0;
  static const double textFieldHeight = 56.0;
  static const double cardHeight = 120.0;
  static const double appBarHeight = 56.0;
  
  // أسماء الشاشات
  static const String splashScreen = '/';
  static const String loginScreen = '/login';
  static const String dashboardScreen = '/dashboard';
  static const String tenantsScreen = '/tenants';
  static const String unitsScreen = '/units';
  static const String maintenanceScreen = '/maintenance';
  static const String reportsScreen = '/reports';
  
  // رسائل التنبيه
  static const String networkError = 'خطأ في الاتصال بالشبكة';
  static const String serverError = 'خطأ في الخادم';
  static const String unknownError = 'حدث خطأ غير متوقع';
  static const String loginRequired = 'يرجى تسجيل الدخول أولاً';
  static const String invalidCredentials = 'بيانات الدخول غير صحيحة';
  
  // التحقق من صحة البيانات
  static const int minPasswordLength = 8;
  static const int maxPasswordLength = 128;
  static const int minNameLength = 2;
  static const int maxNameLength = 50;
  
  // تكوين الشبكة
  static const int connectionTimeout = 30000; // 30 ثانية
  static const int receiveTimeout = 30000; // 30 ثانية
  static const int sendTimeout = 30000; // 30 ثانية
  
  // أنواع المستخدمين
  static const String adminRole = 'admin';
  static const String managerRole = 'manager';
  static const String employeeRole = 'employee';
  static const String tenantRole = 'tenant';
  
  // أنواع الوحدات التجارية
  static const String retailUnit = 'retail';
  static const String foodCourtUnit = 'food_court';
  static const String serviceUnit = 'service';
  static const String officeUnit = 'office';
  static const String storageUnit = 'storage';
  
  // حالات الصيانة
  static const String pendingStatus = 'pending';
  static const String inProgressStatus = 'in_progress';
  static const String completedStatus = 'completed';
  static const String cancelledStatus = 'cancelled';
  
  // أولويات الصيانة
  static const String lowPriority = 'low';
  static const String mediumPriority = 'medium';
  static const String highPriority = 'high';
  static const String urgentPriority = 'urgent';
  
  // تنسيقات التاريخ
  static const String dateFormat = 'yyyy-MM-dd';
  static const String timeFormat = 'HH:mm';
  static const String dateTimeFormat = 'yyyy-MM-dd HH:mm';
  static const String arabicDateFormat = 'dd/MM/yyyy';
  
  // رسائل النجاح
  static const String loginSuccess = 'تم تسجيل الدخول بنجاح';
  static const String logoutSuccess = 'تم تسجيل الخروج بنجاح';
  static const String saveSuccess = 'تم الحفظ بنجاح';
  static const String updateSuccess = 'تم التحديث بنجاح';
  static const String deleteSuccess = 'تم الحذف بنجاح';
}