package com.smartmall.crm.smart_mall_crm_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
