from datetime import datetime
from bson import ObjectId

class Unit:
    def __init__(self, mongo):
        self.collection = mongo.db.units
    
    def create_unit(self, unit_data):
        """Create a new unit"""
        unit_data['createdAt'] = datetime.utcnow()
        unit_data['updatedAt'] = datetime.utcnow()
        unit_data['status'] = unit_data.get('status', 'vacant')
        
        result = self.collection.insert_one(unit_data)
        return str(result.inserted_id)
    
    def find_by_id(self, unit_id):
        """Find unit by ID"""
        return self.collection.find_one({'_id': ObjectId(unit_id)})
    
    def find_by_number(self, unit_number):
        """Find unit by unit number"""
        return self.collection.find_one({'unitNumber': unit_number})
    
    def get_units(self, page=1, limit=10, filters=None):
        """Get paginated list of units"""
        skip = (page - 1) * limit
        query = filters or {}
        
        # Build aggregation pipeline to include tenant info
        pipeline = [
            {'$match': query},
            {
                '$lookup': {
                    'from': 'tenants',
                    'localField': 'currentTenant',
                    'foreignField': '_id',
                    'as': 'tenant'
                }
            },
            {
                '$addFields': {
                    'tenant': {'$arrayElemAt': ['$tenant', 0]}
                }
            },
            {'$skip': skip},
            {'$limit': limit}
        ]
        
        units = list(self.collection.aggregate(pipeline))
        total = self.collection.count_documents(query)
        
        # Convert ObjectId to string
        for unit in units:
            unit['_id'] = str(unit['_id'])
            if unit.get('tenant'):
                unit['tenant']['_id'] = str(unit['tenant']['_id'])
        
        return {
            'units': units,
            'total': total,
            'page': page,
            'pages': (total + limit - 1) // limit
        }
    
    def update_unit(self, unit_id, update_data):
        """Update unit data"""
        update_data['updatedAt'] = datetime.utcnow()
        
        result = self.collection.update_one(
            {'_id': ObjectId(unit_id)},
            {'$set': update_data}
        )
        return result.modified_count > 0
    
    def assign_tenant(self, unit_id, tenant_id):
        """Assign tenant to unit"""
        result = self.collection.update_one(
            {'_id': ObjectId(unit_id)},
            {
                '$set': {
                    'currentTenant': ObjectId(tenant_id),
                    'status': 'occupied',
                    'updatedAt': datetime.utcnow()
                }
            }
        )
        return result.modified_count > 0
    
    def remove_tenant(self, unit_id):
        """Remove tenant from unit"""
        result = self.collection.update_one(
            {'_id': ObjectId(unit_id)},
            {
                '$unset': {'currentTenant': ''},
                '$set': {
                    'status': 'vacant',
                    'updatedAt': datetime.utcnow()
                }
            }
        )
        return result.modified_count > 0
    
    def get_occupancy_stats(self):
        """Get occupancy statistics"""
        pipeline = [
            {
                '$group': {
                    '_id': '$status',
                    'count': {'$sum': 1}
                }
            }
        ]
        
        stats = list(self.collection.aggregate(pipeline))
        
        # Convert to dictionary
        result = {'vacant': 0, 'occupied': 0, 'maintenance': 0, 'reserved': 0}
        for stat in stats:
            result[stat['_id']] = stat['count']
        
        total = sum(result.values())
        result['total'] = total
        result['occupancyRate'] = (result['occupied'] / total * 100) if total > 0 else 0
        
        return result
    
    def delete_unit(self, unit_id):
        """Delete unit"""
        result = self.collection.delete_one({'_id': ObjectId(unit_id)})
        return result.deleted_count > 0

