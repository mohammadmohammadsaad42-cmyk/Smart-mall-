from flask import Blueprint, jsonify

permits_bp = Blueprint('permits', __name__)

@permits_bp.route('', methods=['GET'])
def get_permits():
    return jsonify({'success': True, 'message': 'Permits endpoint - under development'})

@permits_bp.route('', methods=['POST'])
def create_permit():
    return jsonify({'success': True, 'message': 'Create permit endpoint - under development'})

