from datetime import datetime
from bson import ObjectId

class Tenant:
    def __init__(self, mongo):
        self.collection = mongo.db.tenants
    
    def create_tenant(self, tenant_data):
        """Create a new tenant"""
        tenant_data['createdAt'] = datetime.utcnow()
        tenant_data['updatedAt'] = datetime.utcnow()
        tenant_data['status'] = tenant_data.get('status', 'active')
        
        result = self.collection.insert_one(tenant_data)
        return str(result.inserted_id)
    
    def find_by_id(self, tenant_id):
        """Find tenant by ID"""
        return self.collection.find_one({'_id': ObjectId(tenant_id)})
    
    def find_by_commercial_register(self, cr_number):
        """Find tenant by commercial register number"""
        return self.collection.find_one({'commercialRegister.number': cr_number})
    
    def get_tenants(self, page=1, limit=10, filters=None):
        """Get paginated list of tenants"""
        skip = (page - 1) * limit
        query = filters or {}
        
        # Build aggregation pipeline to include units info
        pipeline = [
            {'$match': query},
            {
                '$lookup': {
                    'from': 'units',
                    'localField': '_id',
                    'foreignField': 'currentTenant',
                    'as': 'units'
                }
            },
            {
                '$lookup': {
                    'from': 'contracts',
                    'localField': '_id',
                    'foreignField': 'tenant',
                    'as': 'contracts'
                }
            },
            {'$skip': skip},
            {'$limit': limit}
        ]
        
        tenants = list(self.collection.aggregate(pipeline))
        total = self.collection.count_documents(query)
        
        # Convert ObjectId to string
        for tenant in tenants:
            tenant['_id'] = str(tenant['_id'])
            for unit in tenant.get('units', []):
                unit['_id'] = str(unit['_id'])
            for contract in tenant.get('contracts', []):
                contract['_id'] = str(contract['_id'])
        
        return {
            'tenants': tenants,
            'total': total,
            'page': page,
            'pages': (total + limit - 1) // limit
        }
    
    def update_tenant(self, tenant_id, update_data):
        """Update tenant data"""
        update_data['updatedAt'] = datetime.utcnow()
        
        result = self.collection.update_one(
            {'_id': ObjectId(tenant_id)},
            {'$set': update_data}
        )
        return result.modified_count > 0
    
    def get_tenant_with_details(self, tenant_id):
        """Get tenant with full details including units and contracts"""
        pipeline = [
            {'$match': {'_id': ObjectId(tenant_id)}},
            {
                '$lookup': {
                    'from': 'units',
                    'localField': '_id',
                    'foreignField': 'currentTenant',
                    'as': 'units'
                }
            },
            {
                '$lookup': {
                    'from': 'contracts',
                    'localField': '_id',
                    'foreignField': 'tenant',
                    'as': 'contracts'
                }
            },
            {
                '$lookup': {
                    'from': 'invoices',
                    'localField': '_id',
                    'foreignField': 'tenant',
                    'as': 'invoices'
                }
            }
        ]
        
        result = list(self.collection.aggregate(pipeline))
        if result:
            tenant = result[0]
            tenant['_id'] = str(tenant['_id'])
            
            # Convert ObjectIds in related documents
            for unit in tenant.get('units', []):
                unit['_id'] = str(unit['_id'])
            for contract in tenant.get('contracts', []):
                contract['_id'] = str(contract['_id'])
            for invoice in tenant.get('invoices', []):
                invoice['_id'] = str(invoice['_id'])
            
            return tenant
        return None
    
    def deactivate_tenant(self, tenant_id):
        """Deactivate tenant"""
        result = self.collection.update_one(
            {'_id': ObjectId(tenant_id)},
            {
                '$set': {
                    'status': 'inactive',
                    'updatedAt': datetime.utcnow()
                }
            }
        )
        return result.modified_count > 0
    
    def get_tenant_stats(self):
        """Get tenant statistics"""
        pipeline = [
            {
                '$group': {
                    '_id': '$status',
                    'count': {'$sum': 1}
                }
            }
        ]
        
        stats = list(self.collection.aggregate(pipeline))
        
        # Convert to dictionary
        result = {'active': 0, 'inactive': 0, 'suspended': 0}
        for stat in stats:
            result[stat['_id']] = stat['count']
        
        result['total'] = sum(result.values())
        
        return result

