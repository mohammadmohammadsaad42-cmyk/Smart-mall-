from flask import Blueprint, jsonify

reports_bp = Blueprint('reports', __name__)

@reports_bp.route('', methods=['GET'])
def get_reports():
    return jsonify({'success': True, 'message': 'Reports endpoint - under development'})

@reports_bp.route('/dashboard', methods=['GET'])
def get_dashboard_stats():
    return jsonify({'success': True, 'message': 'Dashboard stats endpoint - under development'})

