from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.unit import Unit
from bson import ObjectId

units_bp = Blueprint('units', __name__)

@units_bp.route('', methods=['GET'])
@jwt_required()
def get_units():
    """Get list of units"""
    try:
        # Get query parameters
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 10))
        status = request.args.get('status')
        floor = request.args.get('floor')
        unit_type = request.args.get('type')
        
        # Build filters
        filters = {}
        if status:
            filters['status'] = status
        if floor:
            filters['floor'] = int(floor)
        if unit_type:
            filters['type'] = unit_type
        
        unit_model = Unit(current_app.mongo)
        result = unit_model.get_units(page, limit, filters)
        
        return jsonify({
            'success': True,
            'data': result['units'],
            'pagination': {
                'page': result['page'],
                'limit': limit,
                'total': result['total'],
                'pages': result['pages']
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'حدث خطأ أثناء جلب قائمة الوحدات',
            'error': str(e)
        }), 500

@units_bp.route('', methods=['POST'])
@jwt_required()
def create_unit():
    """Create new unit"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'message': 'البيانات مطلوبة'
            }), 400
        
        # Required fields
        required_fields = ['unitNumber', 'floor', 'area', 'type']
        for field in required_fields:
            if not data.get(field):
                return jsonify({
                    'success': False,
                    'message': f'{field} مطلوب'
                }), 400
        
        unit_model = Unit(current_app.mongo)
        
        # Check if unit number already exists
        existing_unit = unit_model.find_by_number(data['unitNumber'])
        if existing_unit:
            return jsonify({
                'success': False,
                'message': 'رقم الوحدة موجود بالفعل'
            }), 409
        
        # Create unit
        unit_id = unit_model.create_unit(data)
        
        return jsonify({
            'success': True,
            'message': 'تم إنشاء الوحدة بنجاح',
            'data': {
                'unitId': unit_id
            }
        }), 201
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'حدث خطأ أثناء إنشاء الوحدة',
            'error': str(e)
        }), 500

@units_bp.route('/stats', methods=['GET'])
@jwt_required()
def get_unit_stats():
    """Get unit statistics"""
    try:
        unit_model = Unit(current_app.mongo)
        stats = unit_model.get_occupancy_stats()
        
        return jsonify({
            'success': True,
            'data': stats
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'حدث خطأ أثناء جلب إحصائيات الوحدات',
            'error': str(e)
        }), 500

