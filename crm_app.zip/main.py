import os
import sys
from datetime import datetime, timedelta
from flask import Flask, request, jsonify, render_template_string
from flask_pymongo import PyMongo
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from flask_talisman import Talisman
from flask_wtf.csrf import CSRFProtect
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from dotenv import load_dotenv
import logging

# Load environment variables
load_dotenv()

# Add src directory to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

app = Flask(__name__)

# Security Configuration
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')
app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', 'jwt-secret-key-change-in-production')
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=24)
app.config['JWT_REFRESH_TOKEN_EXPIRES'] = timedelta(days=30)

# Database Configuration
app.config['MONGO_URI'] = os.getenv('MONGODB_URI', 'mongodb://localhost:27017/smart_mall_db')

# File Upload Security
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB
app.config['UPLOAD_FOLDER'] = 'uploads'

# Session Security
app.config.update(
    SESSION_COOKIE_SECURE=True,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
    PERMANENT_SESSION_LIFETIME=timedelta(hours=24)
)

# Initialize extensions
mongo = PyMongo(app)
jwt = JWTManager(app)
cors = CORS(app, origins=["http://localhost:3000", "http://localhost:5173"])

# Security Headers with Talisman
csp = {
    'default-src': "'self'",
    'script-src': "'self' 'unsafe-inline'",
    'style-src': "'self' 'unsafe-inline'",
    'img-src': "'self' data: https:",
    'font-src': "'self' https:",
    'connect-src': "'self'",
    'frame-ancestors': "'none'"
}

Talisman(app, 
    force_https=False,  # Set to True in production
    strict_transport_security=True,
    content_security_policy=csp
)

# CSRF Protection
csrf = CSRFProtect(app)

# Rate Limiting
limiter = Limiter(
    key_func=get_remote_address,
    default_limits=["1000 per day", "100 per hour"],
    storage_uri="memory://"
)
limiter.init_app(app)

# Security Logging
security_logger = logging.getLogger('security')
security_logger.setLevel(logging.INFO)
handler = logging.FileHandler('security.log')
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
security_logger.addHandler(handler)

def log_security_event(event_type, user_id=None, details=""):
    """Log security events"""
    security_logger.info(f"{event_type} - User: {user_id} - {details} - IP: {request.remote_addr}")

# Import routes
from routes.auth import auth_bp
from routes.users import users_bp
from routes.units import units_bp
from routes.tenants import tenants_bp
from routes.maintenance import maintenance_bp
from routes.permits import permits_bp
from routes.invoices import invoices_bp
from routes.notifications import notifications_bp
from routes.reports import reports_bp

# Register blueprints with rate limiting
app.register_blueprint(auth_bp, url_prefix='/api/v1/auth')
app.register_blueprint(users_bp, url_prefix='/api/v1/users')
app.register_blueprint(units_bp, url_prefix='/api/v1/units')
app.register_blueprint(tenants_bp, url_prefix='/api/v1/tenants')
app.register_blueprint(maintenance_bp, url_prefix='/api/v1/maintenance')
app.register_blueprint(permits_bp, url_prefix='/api/v1/permits')
app.register_blueprint(invoices_bp, url_prefix='/api/v1/invoices')
app.register_blueprint(notifications_bp, url_prefix='/api/v1/notifications')
app.register_blueprint(reports_bp, url_prefix='/api/v1/reports')

# Health check endpoint
@app.route('/api/v1/health', methods=['GET'])
@limiter.limit("10 per minute")
def health_check():
    """Health check endpoint"""
    try:
        # Test database connection
        mongo.db.command('ping')
        log_security_event("HEALTH_CHECK", details="Database connection successful")
        return jsonify({
            'success': True,
            'message': 'API is running',
            'database': 'connected',
            'timestamp': datetime.utcnow().isoformat()
        })
    except Exception as e:
        log_security_event("HEALTH_CHECK_FAILED", details=f"Database connection failed: {str(e)}")
        return jsonify({
            'success': False,
            'message': 'Database connection failed',
            'error': str(e)
        }), 500

# Main API info endpoint
@app.route('/', methods=['GET'])
@csrf.exempt  # Exempt from CSRF for public endpoint
def api_info():
    """API information endpoint"""
    return render_template_string('''
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Smart Mall Management API</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
            .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            h1 { color: #2c3e50; text-align: center; }
            .endpoint { background: #ecf0f1; padding: 15px; margin: 10px 0; border-radius: 5px; }
            .method { display: inline-block; padding: 5px 10px; border-radius: 3px; color: white; font-weight: bold; margin-right: 10px; }
            .get { background: #27ae60; }
            .post { background: #3498db; }
            .put { background: #f39c12; }
            .delete { background: #e74c3c; }
            .security-info { background: #d5f4e6; padding: 15px; border-radius: 5px; margin: 20px 0; }
            .security-info h3 { color: #27ae60; margin-top: 0; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🏢 Smart Mall Management API</h1>
            
            <div class="security-info">
                <h3>🔒 Security Features</h3>
                <ul>
                    <li>JWT Authentication & Authorization</li>
                    <li>CSRF Protection</li>
                    <li>Rate Limiting</li>
                    <li>Security Headers (HSTS, CSP, X-Frame-Options)</li>
                    <li>Input Validation & Sanitization</li>
                    <li>Security Event Logging</li>
                </ul>
            </div>
            
            <h2>📋 Available Endpoints</h2>
            
            <div class="endpoint">
                <span class="method get">GET</span>
                <strong>/api/v1/health</strong> - Health check
            </div>
            
            <div class="endpoint">
                <span class="method post">POST</span>
                <strong>/api/v1/auth/login</strong> - User login
            </div>
            
            <div class="endpoint">
                <span class="method post">POST</span>
                <strong>/api/v1/auth/register</strong> - User registration
            </div>
            
            <div class="endpoint">
                <span class="method get">GET</span>
                <strong>/api/v1/users/profile</strong> - Get user profile
            </div>
            
            <div class="endpoint">
                <span class="method get">GET</span>
                <strong>/api/v1/units</strong> - Get units list
            </div>
            
            <div class="endpoint">
                <span class="method post">POST</span>
                <strong>/api/v1/units</strong> - Create new unit
            </div>
            
            <div class="endpoint">
                <span class="method get">GET</span>
                <strong>/api/v1/units/stats</strong> - Get unit statistics
            </div>
            
            <p style="text-align: center; color: #7f8c8d; margin-top: 30px;">
                Version 1.0.0 | Secured with OWASP Best Practices
            </p>
        </div>
    </body>
    </html>
    ''')

# Error handlers with security logging
@app.errorhandler(400)
def bad_request(error):
    log_security_event("BAD_REQUEST", details=f"400 error: {request.url}")
    return jsonify({'success': False, 'message': 'طلب غير صحيح'}), 400

@app.errorhandler(401)
def unauthorized(error):
    log_security_event("UNAUTHORIZED_ACCESS", details=f"401 error: {request.url}")
    return jsonify({'success': False, 'message': 'غير مخول للوصول'}), 401

@app.errorhandler(403)
def forbidden(error):
    log_security_event("FORBIDDEN_ACCESS", details=f"403 error: {request.url}")
    return jsonify({'success': False, 'message': 'ممنوع الوصول'}), 403

@app.errorhandler(404)
def not_found(error):
    return jsonify({'success': False, 'message': 'المورد غير موجود'}), 404

@app.errorhandler(429)
def ratelimit_handler(e):
    log_security_event("RATE_LIMIT_EXCEEDED", details=f"Rate limit exceeded: {request.url}")
    return jsonify({'success': False, 'message': 'تم تجاوز الحد المسموح من الطلبات'}), 429

@app.errorhandler(500)
def internal_error(error):
    log_security_event("INTERNAL_ERROR", details=f"500 error: {request.url}")
    return jsonify({'success': False, 'message': 'خطأ داخلي في الخادم'}), 500

# Security middleware
@app.before_request
def security_middleware():
    """Security middleware to log and validate requests"""
    # Log all requests
    log_security_event("REQUEST", details=f"{request.method} {request.url}")
    
    # Block suspicious requests
    user_agent = request.headers.get('User-Agent', '')
    if 'sqlmap' in user_agent.lower() or 'nikto' in user_agent.lower():
        log_security_event("SUSPICIOUS_REQUEST", details=f"Blocked suspicious user agent: {user_agent}")
        return jsonify({'success': False, 'message': 'طلب مشبوه'}), 403

if __name__ == '__main__':
    # Create upload directory if it doesn't exist
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    
    # Run the application
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=os.getenv('FLASK_DEBUG', 'False').lower() == 'true'
    )

