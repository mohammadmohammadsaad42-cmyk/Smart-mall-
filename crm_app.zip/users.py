from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.user import User

users_bp = Blueprint('users', __name__)

@users_bp.route('/profile', methods=['GET'])
@jwt_required()
def get_profile():
    """Get user profile"""
    try:
        current_user_id = get_jwt_identity()
        
        user_model = User(current_app.mongo)
        user = user_model.find_by_id(current_user_id)
        
        if not user:
            return jsonify({
                'success': False,
                'message': 'المستخدم غير موجود'
            }), 404
        
        # Remove password from response
        user.pop('password', None)
        user['_id'] = str(user['_id'])
        
        return jsonify({
            'success': True,
            'data': user
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'حدث خطأ أثناء جلب الملف الشخصي',
            'error': str(e)
        }), 500

@users_bp.route('/profile', methods=['PUT'])
@jwt_required()
def update_profile():
    """Update user profile"""
    try:
        current_user_id = get_jwt_identity()
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'message': 'البيانات مطلوبة'
            }), 400
        
        # Remove sensitive fields that shouldn't be updated via this endpoint
        sensitive_fields = ['password', 'role', 'isActive', 'createdAt', 'updatedAt']
        for field in sensitive_fields:
            data.pop(field, None)
        
        user_model = User(current_app.mongo)
        
        # Check if user exists
        user = user_model.find_by_id(current_user_id)
        if not user:
            return jsonify({
                'success': False,
                'message': 'المستخدم غير موجود'
            }), 404
        
        # Update user
        success = user_model.update_user(current_user_id, data)
        
        if not success:
            return jsonify({
                'success': False,
                'message': 'فشل في تحديث الملف الشخصي'
            }), 500
        
        # Get updated user
        updated_user = user_model.find_by_id(current_user_id)
        updated_user.pop('password', None)
        updated_user['_id'] = str(updated_user['_id'])
        
        return jsonify({
            'success': True,
            'message': 'تم تحديث الملف الشخصي بنجاح',
            'data': updated_user
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'حدث خطأ أثناء تحديث الملف الشخصي',
            'error': str(e)
        }), 500

@users_bp.route('/change-password', methods=['PUT'])
@jwt_required()
def change_password():
    """Change user password"""
    try:
        current_user_id = get_jwt_identity()
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'message': 'البيانات مطلوبة'
            }), 400
        
        current_password = data.get('currentPassword')
        new_password = data.get('newPassword')
        confirm_password = data.get('confirmPassword')
        
        if not all([current_password, new_password, confirm_password]):
            return jsonify({
                'success': False,
                'message': 'جميع الحقول مطلوبة'
            }), 400
        
        if new_password != confirm_password:
            return jsonify({
                'success': False,
                'message': 'كلمة المرور الجديدة وتأكيدها غير متطابقتين'
            }), 400
        
        user_model = User(current_app.mongo)
        user = user_model.find_by_id(current_user_id)
        
        if not user:
            return jsonify({
                'success': False,
                'message': 'المستخدم غير موجود'
            }), 404
        
        # Verify current password
        if not user_model.verify_password(user, current_password):
            return jsonify({
                'success': False,
                'message': 'كلمة المرور الحالية غير صحيحة'
            }), 400
        
        # Validate new password
        from src.routes.auth import validate_password
        is_valid, message = validate_password(new_password)
        if not is_valid:
            return jsonify({
                'success': False,
                'message': message
            }), 400
        
        # Update password
        success = user_model.update_user(current_user_id, {'password': new_password})
        
        if not success:
            return jsonify({
                'success': False,
                'message': 'فشل في تغيير كلمة المرور'
            }), 500
        
        return jsonify({
            'success': True,
            'message': 'تم تغيير كلمة المرور بنجاح'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'حدث خطأ أثناء تغيير كلمة المرور',
            'error': str(e)
        }), 500

@users_bp.route('', methods=['GET'])
@jwt_required()
def get_users():
    """Get list of users (admin only)"""
    try:
        current_user_id = get_jwt_identity()
        
        # Check if current user is admin
        user_model = User(current_app.mongo)
        current_user = user_model.find_by_id(current_user_id)
        
        if not current_user or current_user.get('role') not in ['admin', 'manager']:
            return jsonify({
                'success': False,
                'message': 'غير مصرح لك بهذه العملية'
            }), 403
        
        # Get query parameters
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 10))
        role = request.args.get('role')
        status = request.args.get('status')
        
        # Build filters
        filters = {}
        if role:
            filters['role'] = role
        if status:
            filters['isActive'] = status == 'active'
        
        # Get users
        result = user_model.get_users(page, limit, filters)
        
        return jsonify({
            'success': True,
            'data': result['users'],
            'pagination': {
                'page': result['page'],
                'limit': limit,
                'total': result['total'],
                'pages': result['pages']
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'حدث خطأ أثناء جلب قائمة المستخدمين',
            'error': str(e)
        }), 500

@users_bp.route('/<user_id>', methods=['GET'])
@jwt_required()
def get_user(user_id):
    """Get user by ID (admin only)"""
    try:
        current_user_id = get_jwt_identity()
        
        # Check if current user is admin or requesting their own data
        user_model = User(current_app.mongo)
        current_user = user_model.find_by_id(current_user_id)
        
        if not current_user:
            return jsonify({
                'success': False,
                'message': 'المستخدم غير موجود'
            }), 404
        
        # Allow users to view their own profile or admins to view any profile
        if current_user_id != user_id and current_user.get('role') not in ['admin', 'manager']:
            return jsonify({
                'success': False,
                'message': 'غير مصرح لك بهذه العملية'
            }), 403
        
        # Get user
        user = user_model.find_by_id(user_id)
        
        if not user:
            return jsonify({
                'success': False,
                'message': 'المستخدم غير موجود'
            }), 404
        
        # Remove password from response
        user.pop('password', None)
        user['_id'] = str(user['_id'])
        
        return jsonify({
            'success': True,
            'data': user
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'حدث خطأ أثناء جلب بيانات المستخدم',
            'error': str(e)
        }), 500

