from datetime import datetime
from bson import ObjectId

class MaintenanceRequest:
    def __init__(self, mongo):
        self.collection = mongo.db.maintenance_requests
        self.counter_collection = mongo.db.counters
    
    def _get_next_request_number(self):
        """Generate next request number"""
        current_year = datetime.utcnow().year
        counter_id = f"maintenance_request_{current_year}"
        
        result = self.counter_collection.find_one_and_update(
            {'_id': counter_id},
            {'$inc': {'sequence': 1}},
            upsert=True,
            return_document=True
        )
        
        sequence = result['sequence']
        return f"MR-{current_year}-{sequence:04d}"
    
    def create_request(self, request_data):
        """Create a new maintenance request"""
        request_data['requestNumber'] = self._get_next_request_number()
        request_data['createdAt'] = datetime.utcnow()
        request_data['updatedAt'] = datetime.utcnow()
        request_data['status'] = request_data.get('status', 'new')
        request_data['notes'] = []
        
        # Convert unit and reportedBy to ObjectId if they're strings
        if 'unit' in request_data and isinstance(request_data['unit'], str):
            request_data['unit'] = ObjectId(request_data['unit'])
        if 'reportedBy' in request_data and isinstance(request_data['reportedBy'], str):
            request_data['reportedBy'] = ObjectId(request_data['reportedBy'])
        
        result = self.collection.insert_one(request_data)
        return str(result.inserted_id)
    
    def find_by_id(self, request_id):
        """Find maintenance request by ID"""
        return self.collection.find_one({'_id': ObjectId(request_id)})
    
    def get_requests(self, page=1, limit=10, filters=None):
        """Get paginated list of maintenance requests"""
        skip = (page - 1) * limit
        query = filters or {}
        
        # Build aggregation pipeline to include unit and user info
        pipeline = [
            {'$match': query},
            {
                '$lookup': {
                    'from': 'units',
                    'localField': 'unit',
                    'foreignField': '_id',
                    'as': 'unit'
                }
            },
            {
                '$lookup': {
                    'from': 'users',
                    'localField': 'reportedBy',
                    'foreignField': '_id',
                    'as': 'reportedBy'
                }
            },
            {
                '$lookup': {
                    'from': 'users',
                    'localField': 'assignedTo',
                    'foreignField': '_id',
                    'as': 'assignedTo'
                }
            },
            {
                '$addFields': {
                    'unit': {'$arrayElemAt': ['$unit', 0]},
                    'reportedBy': {'$arrayElemAt': ['$reportedBy', 0]},
                    'assignedTo': {'$arrayElemAt': ['$assignedTo', 0]}
                }
            },
            {'$sort': {'createdAt': -1}},
            {'$skip': skip},
            {'$limit': limit}
        ]
        
        requests = list(self.collection.aggregate(pipeline))
        total = self.collection.count_documents(query)
        
        # Convert ObjectId to string and clean up user data
        for request in requests:
            request['_id'] = str(request['_id'])
            if request.get('unit'):
                request['unit']['_id'] = str(request['unit']['_id'])
            if request.get('reportedBy'):
                request['reportedBy']['_id'] = str(request['reportedBy']['_id'])
                request['reportedBy'].pop('password', None)
            if request.get('assignedTo'):
                request['assignedTo']['_id'] = str(request['assignedTo']['_id'])
                request['assignedTo'].pop('password', None)
        
        return {
            'requests': requests,
            'total': total,
            'page': page,
            'pages': (total + limit - 1) // limit
        }
    
    def update_request(self, request_id, update_data):
        """Update maintenance request"""
        update_data['updatedAt'] = datetime.utcnow()
        
        # Convert assignedTo to ObjectId if it's a string
        if 'assignedTo' in update_data and isinstance(update_data['assignedTo'], str):
            update_data['assignedTo'] = ObjectId(update_data['assignedTo'])
        
        result = self.collection.update_one(
            {'_id': ObjectId(request_id)},
            {'$set': update_data}
        )
        return result.modified_count > 0
    
    def add_note(self, request_id, note_data):
        """Add note to maintenance request"""
        note = {
            'text': note_data['text'],
            'type': note_data.get('type', 'update'),
            'addedBy': ObjectId(note_data['addedBy']) if isinstance(note_data['addedBy'], str) else note_data['addedBy'],
            'timestamp': datetime.utcnow()
        }
        
        result = self.collection.update_one(
            {'_id': ObjectId(request_id)},
            {
                '$push': {'notes': note},
                '$set': {'updatedAt': datetime.utcnow()}
            }
        )
        return result.modified_count > 0
    
    def get_request_stats(self):
        """Get maintenance request statistics"""
        pipeline = [
            {
                '$group': {
                    '_id': '$status',
                    'count': {'$sum': 1}
                }
            }
        ]
        
        stats = list(self.collection.aggregate(pipeline))
        
        # Convert to dictionary
        result = {'new': 0, 'in-progress': 0, 'completed': 0, 'cancelled': 0}
        for stat in stats:
            result[stat['_id']] = stat['count']
        
        result['total'] = sum(result.values())
        
        return result
    
    def get_requests_by_priority(self):
        """Get maintenance requests grouped by priority"""
        pipeline = [
            {
                '$group': {
                    '_id': '$priority',
                    'count': {'$sum': 1}
                }
            }
        ]
        
        stats = list(self.collection.aggregate(pipeline))
        
        # Convert to dictionary
        result = {'low': 0, 'medium': 0, 'high': 0, 'urgent': 0}
        for stat in stats:
            result[stat['_id']] = stat['count']
        
        return result

