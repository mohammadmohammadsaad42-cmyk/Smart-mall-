import pytest
import sys
import os
from unittest.mock import Mock, patch
from datetime import datetime

# Add src directory to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from models.user import User
from models.unit import Unit
from models.tenant import Tenant
from models.maintenance_request import MaintenanceRequest

class TestUserModel:
    """اختبارات نموذج المستخدم"""
    
    def test_user_creation(self):
        """اختبار إنشاء مستخدم جديد"""
        user_data = {
            'email': 'test@example.com',
            'password': 'password123',
            'firstName': 'Test',
            'lastName': 'User',
            'role': 'manager'
        }
        
        user = User(**user_data)
        
        assert user.email == 'test@example.com'
        assert user.firstName == 'Test'
        assert user.lastName == 'User'
        assert user.role == 'manager'
        assert user.isActive is True
        assert isinstance(user.createdAt, datetime)
    
    def test_user_password_hashing(self):
        """اختبار تشفير كلمة المرور"""
        user = User(
            email='test@example.com',
            password='password123',
            firstName='Test',
            lastName='User'
        )
        
        # كلمة المرور يجب أن تكون مشفرة
        assert user.password != 'password123'
        assert len(user.password) > 20  # bcrypt hash length
    
    def test_user_validation(self):
        """اختبار التحقق من صحة بيانات المستخدم"""
        # إيميل غير صحيح
        with pytest.raises(ValueError):
            User(
                email='invalid-email',
                password='password123',
                firstName='Test',
                lastName='User'
            )
        
        # كلمة مرور قصيرة
        with pytest.raises(ValueError):
            User(
                email='test@example.com',
                password='123',
                firstName='Test',
                lastName='User'
            )
    
    def test_user_to_dict(self):
        """اختبار تحويل المستخدم إلى قاموس"""
        user = User(
            email='test@example.com',
            password='password123',
            firstName='Test',
            lastName='User',
            role='manager'
        )
        
        user_dict = user.to_dict()
        
        assert 'password' not in user_dict  # كلمة المرور لا يجب أن تظهر
        assert user_dict['email'] == 'test@example.com'
        assert user_dict['firstName'] == 'Test'
        assert user_dict['role'] == 'manager'

class TestUnitModel:
    """اختبارات نموذج الوحدة"""
    
    def test_unit_creation(self):
        """اختبار إنشاء وحدة جديدة"""
        unit_data = {
            'unitNumber': 'A101',
            'floor': 1,
            'area': 150.5,
            'type': 'retail',
            'monthlyRent': 5000,
            'status': 'available'
        }
        
        unit = Unit(**unit_data)
        
        assert unit.unitNumber == 'A101'
        assert unit.floor == 1
        assert unit.area == 150.5
        assert unit.type == 'retail'
        assert unit.monthlyRent == 5000
        assert unit.status == 'available'
        assert isinstance(unit.createdAt, datetime)
    
    def test_unit_validation(self):
        """اختبار التحقق من صحة بيانات الوحدة"""
        # رقم وحدة فارغ
        with pytest.raises(ValueError):
            Unit(
                unitNumber='',
                floor=1,
                area=150.5,
                type='retail',
                monthlyRent=5000
            )
        
        # مساحة سالبة
        with pytest.raises(ValueError):
            Unit(
                unitNumber='A101',
                floor=1,
                area=-50,
                type='retail',
                monthlyRent=5000
            )
        
        # إيجار سالب
        with pytest.raises(ValueError):
            Unit(
                unitNumber='A101',
                floor=1,
                area=150.5,
                type='retail',
                monthlyRent=-1000
            )
    
    def test_unit_occupancy_calculation(self):
        """اختبار حساب معدل الإشغال"""
        unit = Unit(
            unitNumber='A101',
            floor=1,
            area=150.5,
            type='retail',
            monthlyRent=5000,
            status='occupied'
        )
        
        # محاكاة بيانات الإشغال
        unit.occupancyHistory = [
            {'month': '2024-01', 'occupied': True},
            {'month': '2024-02', 'occupied': True},
            {'month': '2024-03', 'occupied': False},
            {'month': '2024-04', 'occupied': True}
        ]
        
        occupancy_rate = unit.calculate_occupancy_rate()
        assert occupancy_rate == 75.0  # 3 out of 4 months occupied

class TestTenantModel:
    """اختبارات نموذج المستأجر"""
    
    def test_tenant_creation(self):
        """اختبار إنشاء مستأجر جديد"""
        tenant_data = {
            'firstName': 'John',
            'lastName': 'Doe',
            'email': 'john@example.com',
            'phone': '+1234567890',
            'businessName': 'John\'s Store',
            'businessType': 'retail',
            'unitId': 'unit123',
            'leaseStartDate': datetime(2024, 1, 1),
            'leaseEndDate': datetime(2024, 12, 31),
            'monthlyRent': 5000
        }
        
        tenant = Tenant(**tenant_data)
        
        assert tenant.firstName == 'John'
        assert tenant.lastName == 'Doe'
        assert tenant.email == 'john@example.com'
        assert tenant.businessName == 'John\'s Store'
        assert tenant.monthlyRent == 5000
        assert tenant.status == 'active'
    
    def test_tenant_validation(self):
        """اختبار التحقق من صحة بيانات المستأجر"""
        # إيميل غير صحيح
        with pytest.raises(ValueError):
            Tenant(
                firstName='John',
                lastName='Doe',
                email='invalid-email',
                phone='+1234567890',
                businessName='John\'s Store',
                unitId='unit123',
                leaseStartDate=datetime(2024, 1, 1),
                leaseEndDate=datetime(2024, 12, 31),
                monthlyRent=5000
            )
        
        # تاريخ انتهاء الإيجار قبل تاريخ البداية
        with pytest.raises(ValueError):
            Tenant(
                firstName='John',
                lastName='Doe',
                email='john@example.com',
                phone='+1234567890',
                businessName='John\'s Store',
                unitId='unit123',
                leaseStartDate=datetime(2024, 12, 31),
                leaseEndDate=datetime(2024, 1, 1),
                monthlyRent=5000
            )
    
    def test_tenant_lease_status(self):
        """اختبار حالة الإيجار"""
        # إيجار نشط
        active_tenant = Tenant(
            firstName='John',
            lastName='Doe',
            email='john@example.com',
            phone='+1234567890',
            businessName='John\'s Store',
            unitId='unit123',
            leaseStartDate=datetime(2024, 1, 1),
            leaseEndDate=datetime(2024, 12, 31),
            monthlyRent=5000
        )
        
        assert active_tenant.is_lease_active() is True
        
        # إيجار منتهي
        expired_tenant = Tenant(
            firstName='Jane',
            lastName='Smith',
            email='jane@example.com',
            phone='+1234567890',
            businessName='Jane\'s Shop',
            unitId='unit124',
            leaseStartDate=datetime(2023, 1, 1),
            leaseEndDate=datetime(2023, 12, 31),
            monthlyRent=4000
        )
        
        assert expired_tenant.is_lease_active() is False

class TestMaintenanceRequestModel:
    """اختبارات نموذج طلب الصيانة"""
    
    def test_maintenance_request_creation(self):
        """اختبار إنشاء طلب صيانة جديد"""
        request_data = {
            'unitId': 'unit123',
            'tenantId': 'tenant123',
            'type': 'plumbing',
            'priority': 'high',
            'description': 'Water leak in bathroom',
            'reportedBy': 'tenant'
        }
        
        maintenance_request = MaintenanceRequest(**request_data)
        
        assert maintenance_request.unitId == 'unit123'
        assert maintenance_request.tenantId == 'tenant123'
        assert maintenance_request.type == 'plumbing'
        assert maintenance_request.priority == 'high'
        assert maintenance_request.status == 'pending'
        assert isinstance(maintenance_request.requestNumber, str)
        assert len(maintenance_request.requestNumber) > 0
    
    def test_maintenance_request_validation(self):
        """اختبار التحقق من صحة بيانات طلب الصيانة"""
        # نوع صيانة غير صحيح
        with pytest.raises(ValueError):
            MaintenanceRequest(
                unitId='unit123',
                tenantId='tenant123',
                type='invalid_type',
                priority='high',
                description='Test description'
            )
        
        # أولوية غير صحيحة
        with pytest.raises(ValueError):
            MaintenanceRequest(
                unitId='unit123',
                tenantId='tenant123',
                type='plumbing',
                priority='invalid_priority',
                description='Test description'
            )
    
    def test_maintenance_request_number_generation(self):
        """اختبار توليد رقم طلب الصيانة"""
        request1 = MaintenanceRequest(
            unitId='unit123',
            tenantId='tenant123',
            type='plumbing',
            priority='high',
            description='First request'
        )
        
        request2 = MaintenanceRequest(
            unitId='unit124',
            tenantId='tenant124',
            type='electrical',
            priority='medium',
            description='Second request'
        )
        
        # أرقام الطلبات يجب أن تكون مختلفة
        assert request1.requestNumber != request2.requestNumber
        
        # أرقام الطلبات يجب أن تبدأ بـ MR
        assert request1.requestNumber.startswith('MR')
        assert request2.requestNumber.startswith('MR')
    
    def test_maintenance_request_status_update(self):
        """اختبار تحديث حالة طلب الصيانة"""
        maintenance_request = MaintenanceRequest(
            unitId='unit123',
            tenantId='tenant123',
            type='plumbing',
            priority='high',
            description='Water leak'
        )
        
        # تحديث الحالة إلى قيد التنفيذ
        maintenance_request.update_status('in_progress', 'technician123')
        
        assert maintenance_request.status == 'in_progress'
        assert maintenance_request.assignedTo == 'technician123'
        assert maintenance_request.updatedAt > maintenance_request.createdAt
        
        # تحديث الحالة إلى مكتمل
        maintenance_request.update_status('completed', 'technician123', 'Fixed the leak')
        
        assert maintenance_request.status == 'completed'
        assert maintenance_request.completionNotes == 'Fixed the leak'
        assert maintenance_request.completedAt is not None

class TestModelIntegration:
    """اختبارات تكامل النماذج"""
    
    def test_unit_tenant_relationship(self):
        """اختبار العلاقة بين الوحدة والمستأجر"""
        unit = Unit(
            unitNumber='A101',
            floor=1,
            area=150.5,
            type='retail',
            monthlyRent=5000,
            status='available'
        )
        
        tenant = Tenant(
            firstName='John',
            lastName='Doe',
            email='john@example.com',
            phone='+1234567890',
            businessName='John\'s Store',
            unitId=str(unit._id) if hasattr(unit, '_id') else 'unit123',
            leaseStartDate=datetime(2024, 1, 1),
            leaseEndDate=datetime(2024, 12, 31),
            monthlyRent=5000
        )
        
        # عند إضافة مستأجر، يجب تحديث حالة الوحدة
        unit.status = 'occupied'
        unit.currentTenant = str(tenant._id) if hasattr(tenant, '_id') else 'tenant123'
        
        assert unit.status == 'occupied'
        assert unit.currentTenant is not None
    
    def test_tenant_maintenance_relationship(self):
        """اختبار العلاقة بين المستأجر وطلبات الصيانة"""
        tenant = Tenant(
            firstName='John',
            lastName='Doe',
            email='john@example.com',
            phone='+1234567890',
            businessName='John\'s Store',
            unitId='unit123',
            leaseStartDate=datetime(2024, 1, 1),
            leaseEndDate=datetime(2024, 12, 31),
            monthlyRent=5000
        )
        
        maintenance_request = MaintenanceRequest(
            unitId='unit123',
            tenantId=str(tenant._id) if hasattr(tenant, '_id') else 'tenant123',
            type='plumbing',
            priority='high',
            description='Water leak',
            reportedBy='tenant'
        )
        
        assert maintenance_request.tenantId == (str(tenant._id) if hasattr(tenant, '_id') else 'tenant123')
        assert maintenance_request.unitId == tenant.unitId

if __name__ == '__main__':
    pytest.main(['-v', '--cov=src/models', '--cov-report=html', '--cov-report=term'])

