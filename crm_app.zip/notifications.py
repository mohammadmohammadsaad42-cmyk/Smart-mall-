from flask import Blueprint, jsonify

notifications_bp = Blueprint('notifications', __name__)

@notifications_bp.route('', methods=['GET'])
def get_notifications():
    return jsonify({'success': True, 'message': 'Notifications endpoint - under development'})

@notifications_bp.route('', methods=['POST'])
def create_notification():
    return jsonify({'success': True, 'message': 'Create notification endpoint - under development'})

