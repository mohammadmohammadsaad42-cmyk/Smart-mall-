from flask import Blueprint, jsonify

invoices_bp = Blueprint('invoices', __name__)

@invoices_bp.route('', methods=['GET'])
def get_invoices():
    return jsonify({'success': True, 'message': 'Invoices endpoint - under development'})

@invoices_bp.route('', methods=['POST'])
def create_invoice():
    return jsonify({'success': True, 'message': 'Create invoice endpoint - under development'})

