from datetime import datetime
from bson import ObjectId
from werkzeug.security import generate_password_hash, check_password_hash

class User:
    def __init__(self, mongo):
        self.collection = mongo.db.users
    
    def create_user(self, user_data):
        """Create a new user"""
        # Hash password
        if 'password' in user_data:
            user_data['password'] = generate_password_hash(user_data['password'])
        
        # Add timestamps
        user_data['createdAt'] = datetime.utcnow()
        user_data['updatedAt'] = datetime.utcnow()
        user_data['isActive'] = True
        user_data['lastLogin'] = None
        
        # Insert user
        result = self.collection.insert_one(user_data)
        return str(result.inserted_id)
    
    def find_by_email(self, email):
        """Find user by email"""
        return self.collection.find_one({'email': email})
    
    def find_by_id(self, user_id):
        """Find user by ID"""
        return self.collection.find_one({'_id': ObjectId(user_id)})
    
    def verify_password(self, user, password):
        """Verify user password"""
        return check_password_hash(user['password'], password)
    
    def update_last_login(self, user_id):
        """Update user's last login time"""
        self.collection.update_one(
            {'_id': ObjectId(user_id)},
            {'$set': {'lastLogin': datetime.utcnow()}}
        )
    
    def update_user(self, user_id, update_data):
        """Update user data"""
        update_data['updatedAt'] = datetime.utcnow()
        
        # Hash password if provided
        if 'password' in update_data:
            update_data['password'] = generate_password_hash(update_data['password'])
        
        result = self.collection.update_one(
            {'_id': ObjectId(user_id)},
            {'$set': update_data}
        )
        return result.modified_count > 0
    
    def get_users(self, page=1, limit=10, filters=None):
        """Get paginated list of users"""
        skip = (page - 1) * limit
        query = filters or {}
        
        # Exclude password from results
        projection = {'password': 0}
        
        users = list(self.collection.find(query, projection).skip(skip).limit(limit))
        total = self.collection.count_documents(query)
        
        # Convert ObjectId to string
        for user in users:
            user['_id'] = str(user['_id'])
        
        return {
            'users': users,
            'total': total,
            'page': page,
            'pages': (total + limit - 1) // limit
        }
    
    def delete_user(self, user_id):
        """Soft delete user (deactivate)"""
        result = self.collection.update_one(
            {'_id': ObjectId(user_id)},
            {'$set': {'isActive': False, 'updatedAt': datetime.utcnow()}}
        )
        return result.modified_count > 0

