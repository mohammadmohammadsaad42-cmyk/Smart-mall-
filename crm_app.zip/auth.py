from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import create_access_token, create_refresh_token, jwt_required, get_jwt_identity
from src.models.user import User
import re

auth_bp = Blueprint('auth', __name__)

def validate_email(email):
    """Validate email format"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_password(password):
    """Validate password strength"""
    if len(password) < 8:
        return False, "كلمة المرور يجب أن تكون 8 أحرف على الأقل"
    if not re.search(r'[A-Za-z]', password):
        return False, "كلمة المرور يجب أن تحتوي على حروف"
    if not re.search(r'\d', password):
        return False, "كلمة المرور يجب أن تحتوي على أرقام"
    return True, ""

@auth_bp.route('/login', methods=['POST'])
def login():
    """User login"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'message': 'البيانات مطلوبة'
            }), 400
        
        email = data.get('email')
        password = data.get('password')
        
        if not email or not password:
            return jsonify({
                'success': False,
                'message': 'البريد الإلكتروني وكلمة المرور مطلوبان'
            }), 400
        
        # Validate email format
        if not validate_email(email):
            return jsonify({
                'success': False,
                'message': 'تنسيق البريد الإلكتروني غير صحيح'
            }), 400
        
        user_model = User(current_app.mongo)
        user = user_model.find_by_email(email)
        
        if not user:
            return jsonify({
                'success': False,
                'message': 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
            }), 401
        
        if not user.get('isActive', True):
            return jsonify({
                'success': False,
                'message': 'الحساب غير نشط'
            }), 401
        
        if not user_model.verify_password(user, password):
            return jsonify({
                'success': False,
                'message': 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
            }), 401
        
        # Update last login
        user_model.update_last_login(str(user['_id']))
        
        # Create tokens
        access_token = create_access_token(identity=str(user['_id']))
        refresh_token = create_refresh_token(identity=str(user['_id']))
        
        # Remove password from response
        user.pop('password', None)
        user['_id'] = str(user['_id'])
        
        return jsonify({
            'success': True,
            'message': 'تم تسجيل الدخول بنجاح',
            'data': {
                'user': user,
                'token': access_token,
                'refreshToken': refresh_token
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'حدث خطأ أثناء تسجيل الدخول',
            'error': str(e)
        }), 500

@auth_bp.route('/register', methods=['POST'])
def register():
    """User registration"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'message': 'البيانات مطلوبة'
            }), 400
        
        # Required fields
        required_fields = ['email', 'password', 'firstName', 'lastName', 'role']
        for field in required_fields:
            if not data.get(field):
                return jsonify({
                    'success': False,
                    'message': f'{field} مطلوب'
                }), 400
        
        email = data['email']
        password = data['password']
        
        # Validate email
        if not validate_email(email):
            return jsonify({
                'success': False,
                'message': 'تنسيق البريد الإلكتروني غير صحيح'
            }), 400
        
        # Validate password
        is_valid, message = validate_password(password)
        if not is_valid:
            return jsonify({
                'success': False,
                'message': message
            }), 400
        
        # Validate role
        valid_roles = ['admin', 'manager', 'tenant', 'technician', 'finance']
        if data['role'] not in valid_roles:
            return jsonify({
                'success': False,
                'message': 'نوع المستخدم غير صحيح'
            }), 400
        
        user_model = User(current_app.mongo)
        
        # Check if user already exists
        existing_user = user_model.find_by_email(email)
        if existing_user:
            return jsonify({
                'success': False,
                'message': 'المستخدم موجود بالفعل'
            }), 409
        
        # Create user
        user_id = user_model.create_user(data)
        
        return jsonify({
            'success': True,
            'message': 'تم إنشاء الحساب بنجاح',
            'data': {
                'userId': user_id
            }
        }), 201
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'حدث خطأ أثناء إنشاء الحساب',
            'error': str(e)
        }), 500

@auth_bp.route('/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh():
    """Refresh access token"""
    try:
        current_user_id = get_jwt_identity()
        
        user_model = User(current_app.mongo)
        user = user_model.find_by_id(current_user_id)
        
        if not user or not user.get('isActive', True):
            return jsonify({
                'success': False,
                'message': 'المستخدم غير موجود أو غير نشط'
            }), 401
        
        # Create new tokens
        access_token = create_access_token(identity=current_user_id)
        refresh_token = create_refresh_token(identity=current_user_id)
        
        return jsonify({
            'success': True,
            'data': {
                'token': access_token,
                'refreshToken': refresh_token
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'حدث خطأ أثناء تجديد الرمز المميز',
            'error': str(e)
        }), 500

@auth_bp.route('/logout', methods=['POST'])
@jwt_required()
def logout():
    """User logout"""
    try:
        # In a production environment, you would add the token to a blacklist
        # For now, we'll just return a success message
        return jsonify({
            'success': True,
            'message': 'تم تسجيل الخروج بنجاح'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'حدث خطأ أثناء تسجيل الخروج',
            'error': str(e)
        }), 500

@auth_bp.route('/me', methods=['GET'])
@jwt_required()
def get_current_user():
    """Get current user info"""
    try:
        current_user_id = get_jwt_identity()
        
        user_model = User(current_app.mongo)
        user = user_model.find_by_id(current_user_id)
        
        if not user:
            return jsonify({
                'success': False,
                'message': 'المستخدم غير موجود'
            }), 404
        
        # Remove password from response
        user.pop('password', None)
        user['_id'] = str(user['_id'])
        
        return jsonify({
            'success': True,
            'data': user
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'حدث خطأ أثناء جلب بيانات المستخدم',
            'error': str(e)
        }), 500

