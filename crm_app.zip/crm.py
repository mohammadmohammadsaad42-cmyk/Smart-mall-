from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime
import os
from simple_salesforce import Salesforce
from dotenv import load_dotenv

load_dotenv()

crm_bp = Blueprint('crm', __name__)

class CRMIntegration:
    def __init__(self):
        self.salesforce_client = None
        self.hubspot_client = None
        self.zoho_client = None
        self._initialize_clients()
    
    def _initialize_clients(self):
        """تهيئة عملاء CRM"""
        try:
            # Salesforce
            if all([os.getenv('SALESFORCE_USERNAME'), 
                   os.getenv('SALESFORCE_PASSWORD'), 
                   os.getenv('SALESFORCE_SECURITY_TOKEN')]):
                self.salesforce_client = Salesforce(
                    username=os.getenv('SALESFORCE_USERNAME'),
                    password=os.getenv('SALESFORCE_PASSWORD'),
                    security_token=os.getenv('SALESFORCE_SECURITY_TOKEN'),
                    domain=os.getenv('SALESFORCE_DOMAIN', 'login')
                )
        except Exception as e:
            print(f"Failed to initialize Salesforce: {e}")
    
    def sync_tenant_to_crm(self, tenant_data, crm_type='salesforce'):
        """مزامنة بيانات المستأجر مع CRM"""
        try:
            if crm_type == 'salesforce' and self.salesforce_client:
                return self._sync_to_salesforce(tenant_data)
            elif crm_type == 'hubspot' and self.hubspot_client:
                return self._sync_to_hubspot(tenant_data)
            elif crm_type == 'zoho' and self.zoho_client:
                return self._sync_to_zoho(tenant_data)
            else:
                return {'success': False, 'error': f'CRM {crm_type} not configured'}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _sync_to_salesforce(self, tenant_data):
        """مزامنة مع Salesforce"""
        contact_data = {
            'FirstName': tenant_data.get('firstName', ''),
            'LastName': tenant_data.get('lastName', ''),
            'Email': tenant_data.get('email', ''),
            'Phone': tenant_data.get('phone', ''),
            'Account_Type__c': 'Tenant',
            'Unit_Number__c': tenant_data.get('unitNumber', ''),
            'Business_Name__c': tenant_data.get('businessName', ''),
            'Lease_Start_Date__c': tenant_data.get('leaseStartDate', ''),
            'Lease_End_Date__c': tenant_data.get('leaseEndDate', ''),
            'Monthly_Rent__c': tenant_data.get('monthlyRent', 0)
        }
        
        # البحث عن جهة اتصال موجودة
        existing_contact = self.salesforce_client.query(
            f"SELECT Id FROM Contact WHERE Email = '{tenant_data.get('email')}'"
        )
        
        if existing_contact['records']:
            # تحديث جهة اتصال موجودة
            contact_id = existing_contact['records'][0]['Id']
            result = self.salesforce_client.Contact.update(contact_id, contact_data)
            return {'success': True, 'action': 'updated', 'contact_id': contact_id}
        else:
            # إنشاء جهة اتصال جديدة
            result = self.salesforce_client.Contact.create(contact_data)
            return {'success': True, 'action': 'created', 'contact_id': result['id']}

# تهيئة CRM Integration
crm_integration = CRMIntegration()

@crm_bp.route('/sync-tenant', methods=['POST'])
@jwt_required()
def sync_tenant_to_crm():
    """مزامنة بيانات المستأجر مع CRM"""
    try:
        data = request.get_json()
        tenant_data = data.get('tenant_data')
        crm_type = data.get('crm_type', 'salesforce')
        
        if not tenant_data:
            return jsonify({'success': False, 'error': 'بيانات المستأجر مطلوبة'}), 400
        
        result = crm_integration.sync_tenant_to_crm(tenant_data, crm_type)
        
        if result['success']:
            return jsonify({
                'success': True,
                'message': 'تم مزامنة البيانات بنجاح',
                'result': result
            })
        else:
            return jsonify({
                'success': False,
                'error': result['error']
            }), 500
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@crm_bp.route('/sync-maintenance-request', methods=['POST'])
@jwt_required()
def sync_maintenance_to_crm():
    """مزامنة طلب الصيانة مع CRM"""
    try:
        data = request.get_json()
        maintenance_data = data.get('maintenance_data')
        crm_type = data.get('crm_type', 'salesforce')
        
        if not maintenance_data:
            return jsonify({'success': False, 'error': 'بيانات طلب الصيانة مطلوبة'}), 400
        
        # تحويل طلب الصيانة إلى Case في Salesforce
        if crm_type == 'salesforce' and crm_integration.salesforce_client:
            case_data = {
                'Subject': f"طلب صيانة - {maintenance_data.get('type', 'عام')}",
                'Description': maintenance_data.get('description', ''),
                'Priority': maintenance_data.get('priority', 'Medium'),
                'Status': 'New',
                'Origin': 'Smart Mall App',
                'Unit_Number__c': maintenance_data.get('unitNumber', ''),
                'Maintenance_Type__c': maintenance_data.get('type', ''),
                'Requested_Date__c': maintenance_data.get('requestDate', datetime.utcnow().isoformat())
            }
            
            result = crm_integration.salesforce_client.Case.create(case_data)
            
            return jsonify({
                'success': True,
                'message': 'تم إنشاء طلب الصيانة في CRM',
                'case_id': result['id']
            })
        else:
            return jsonify({
                'success': False,
                'error': f'CRM {crm_type} غير مكون'
            }), 400
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@crm_bp.route('/get-crm-data/<contact_id>', methods=['GET'])
@jwt_required()
def get_crm_data(contact_id):
    """استرداد بيانات من CRM"""
    try:
        crm_type = request.args.get('crm_type', 'salesforce')
        
        if crm_type == 'salesforce' and crm_integration.salesforce_client:
            contact = crm_integration.salesforce_client.Contact.get(contact_id)
            
            return jsonify({
                'success': True,
                'contact': contact
            })
        else:
            return jsonify({
                'success': False,
                'error': f'CRM {crm_type} غير مكون'
            }), 400
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@crm_bp.route('/webhook/crm-update', methods=['POST'])
def crm_webhook():
    """استقبال التحديثات من CRM"""
    try:
        data = request.get_json()
        event_type = data.get('event_type')
        
        if event_type == 'contact_updated':
            # تحديث بيانات المستأجر في قاعدة البيانات المحلية
            contact_data = data.get('contact_data')
            # TODO: تحديث قاعدة البيانات المحلية
            
        elif event_type == 'case_updated':
            # تحديث حالة طلب الصيانة
            case_data = data.get('case_data')
            # TODO: تحديث حالة طلب الصيانة في قاعدة البيانات المحلية
        
        return jsonify({'success': True, 'message': 'تم معالجة التحديث'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@crm_bp.route('/crm-status', methods=['GET'])
@jwt_required()
def get_crm_status():
    """فحص حالة اتصال CRM"""
    try:
        status = {
            'salesforce': {
                'connected': crm_integration.salesforce_client is not None,
                'last_sync': None  # TODO: إضافة تتبع آخر مزامنة
            },
            'hubspot': {
                'connected': crm_integration.hubspot_client is not None,
                'last_sync': None
            },
            'zoho': {
                'connected': crm_integration.zoho_client is not None,
                'last_sync': None
            }
        }
        
        return jsonify({
            'success': True,
            'crm_status': status
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

