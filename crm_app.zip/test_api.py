import pytest
import sys
import os
from datetime import datetime, timedelta

# Add src directory to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from main import app
from models.user import User
from models.unit import Unit
from models.tenant import Tenant
from models.maintenance_request import MaintenanceRequest

@pytest.fixture
def client():
    """إنشاء عميل اختبار Flask"""
    app.config['TESTING'] = True
    app.config['MONGO_URI'] = 'mongodb://localhost:27017/smart_mall_test_db'
    app.config['JWT_SECRET_KEY'] = 'test-secret-key'
    
    with app.test_client() as client:
        with app.app_context():
            yield client

@pytest.fixture
def auth_headers(client):
    """إنشاء headers للمصادقة"""
    # إنشاء مستخدم اختبار
    user_data = {
        'email': 'test@example.com',
        'password': 'testpassword123',
        'firstName': 'Test',
        'lastName': 'User',
        'role': 'admin'
    }
    
    # تسجيل المستخدم
    client.post('/api/v1/auth/register', json=user_data)
    
    # تسجيل الدخول
    login_response = client.post('/api/v1/auth/login', json={
        'email': 'test@example.com',
        'password': 'testpassword123'
    })
    
    token = login_response.get_json()['access_token']
    return {'Authorization': f'Bearer {token}'}

class TestAuthRoutes:
    """اختبارات مسارات المصادقة"""
    
    def test_register_success(self, client):
        """اختبار تسجيل مستخدم جديد بنجاح"""
        user_data = {
            'email': 'newuser@example.com',
            'password': 'password123',
            'firstName': 'New',
            'lastName': 'User',
            'role': 'manager'
        }
        
        response = client.post('/api/v1/auth/register', json=user_data)
        data = response.get_json()
        
        assert response.status_code == 201
        assert data['success'] is True
        assert 'user_id' in data
        assert data['message'] == 'تم إنشاء المستخدم بنجاح'
    
    def test_register_duplicate_email(self, client):
        """اختبار تسجيل مستخدم بإيميل موجود"""
        user_data = {
            'email': 'duplicate@example.com',
            'password': 'password123',
            'firstName': 'First',
            'lastName': 'User',
            'role': 'manager'
        }
        
        # تسجيل المستخدم الأول
        client.post('/api/v1/auth/register', json=user_data)
        
        # محاولة تسجيل مستخدم آخر بنفس الإيميل
        response = client.post('/api/v1/auth/register', json=user_data)
        data = response.get_json()
        
        assert response.status_code == 400
        assert data['success'] is False
        assert 'موجود بالفعل' in data['message']
    
    def test_register_invalid_data(self, client):
        """اختبار تسجيل مستخدم ببيانات غير صحيحة"""
        user_data = {
            'email': 'invalid-email',
            'password': '123',  # كلمة مرور قصيرة
            'firstName': '',
            'lastName': 'User'
        }
        
        response = client.post('/api/v1/auth/register', json=user_data)
        data = response.get_json()
        
        assert response.status_code == 400
        assert data['success'] is False
    
    def test_login_success(self, client):
        """اختبار تسجيل الدخول بنجاح"""
        # إنشاء مستخدم أولاً
        user_data = {
            'email': 'login@example.com',
            'password': 'password123',
            'firstName': 'Login',
            'lastName': 'User',
            'role': 'manager'
        }
        client.post('/api/v1/auth/register', json=user_data)
        
        # تسجيل الدخول
        login_data = {
            'email': 'login@example.com',
            'password': 'password123'
        }
        
        response = client.post('/api/v1/auth/login', json=login_data)
        data = response.get_json()
        
        assert response.status_code == 200
        assert data['success'] is True
        assert 'access_token' in data
        assert 'refresh_token' in data
        assert data['user']['email'] == 'login@example.com'
    
    def test_login_invalid_credentials(self, client):
        """اختبار تسجيل الدخول ببيانات خاطئة"""
        login_data = {
            'email': 'nonexistent@example.com',
            'password': 'wrongpassword'
        }
        
        response = client.post('/api/v1/auth/login', json=login_data)
        data = response.get_json()
        
        assert response.status_code == 401
        assert data['success'] is False
        assert 'غير صحيحة' in data['message']

class TestUserRoutes:
    """اختبارات مسارات المستخدمين"""
    
    def test_get_profile_success(self, client, auth_headers):
        """اختبار الحصول على الملف الشخصي"""
        response = client.get('/api/v1/users/profile', headers=auth_headers)
        data = response.get_json()
        
        assert response.status_code == 200
        assert data['success'] is True
        assert 'user' in data
        assert data['user']['email'] == 'test@example.com'
    
    def test_get_profile_unauthorized(self, client):
        """اختبار الحصول على الملف الشخصي بدون مصادقة"""
        response = client.get('/api/v1/users/profile')
        data = response.get_json()
        
        assert response.status_code == 401
        assert data['success'] is False
    
    def test_update_profile_success(self, client, auth_headers):
        """اختبار تحديث الملف الشخصي"""
        update_data = {
            'firstName': 'Updated',
            'lastName': 'Name',
            'phone': '+1234567890'
        }
        
        response = client.put('/api/v1/users/profile', 
                            json=update_data, 
                            headers=auth_headers)
        data = response.get_json()
        
        assert response.status_code == 200
        assert data['success'] is True
        assert data['message'] == 'تم تحديث الملف الشخصي بنجاح'
    
    def test_change_password_success(self, client, auth_headers):
        """اختبار تغيير كلمة المرور"""
        password_data = {
            'currentPassword': 'testpassword123',
            'newPassword': 'newpassword123'
        }
        
        response = client.put('/api/v1/users/change-password', 
                            json=password_data, 
                            headers=auth_headers)
        data = response.get_json()
        
        assert response.status_code == 200
        assert data['success'] is True
        assert data['message'] == 'تم تغيير كلمة المرور بنجاح'
    
    def test_change_password_wrong_current(self, client, auth_headers):
        """اختبار تغيير كلمة المرور بكلمة مرور حالية خاطئة"""
        password_data = {
            'currentPassword': 'wrongpassword',
            'newPassword': 'newpassword123'
        }
        
        response = client.put('/api/v1/users/change-password', 
                            json=password_data, 
                            headers=auth_headers)
        data = response.get_json()
        
        assert response.status_code == 400
        assert data['success'] is False
        assert 'غير صحيحة' in data['message']

class TestUnitRoutes:
    """اختبارات مسارات الوحدات"""
    
    def test_get_units_success(self, client, auth_headers):
        """اختبار الحصول على قائمة الوحدات"""
        response = client.get('/api/v1/units', headers=auth_headers)
        data = response.get_json()
        
        assert response.status_code == 200
        assert data['success'] is True
        assert 'units' in data
        assert isinstance(data['units'], list)
    
    def test_create_unit_success(self, client, auth_headers):
        """اختبار إنشاء وحدة جديدة"""
        unit_data = {
            'unitNumber': 'A101',
            'floor': 1,
            'area': 150.5,
            'type': 'retail',
            'monthlyRent': 5000,
            'status': 'available'
        }
        
        response = client.post('/api/v1/units', 
                             json=unit_data, 
                             headers=auth_headers)
        data = response.get_json()
        
        assert response.status_code == 201
        assert data['success'] is True
        assert 'unit_id' in data
        assert data['message'] == 'تم إنشاء الوحدة بنجاح'
    
    def test_create_unit_duplicate_number(self, client, auth_headers):
        """اختبار إنشاء وحدة برقم موجود"""
        unit_data = {
            'unitNumber': 'A102',
            'floor': 1,
            'area': 150.5,
            'type': 'retail',
            'monthlyRent': 5000,
            'status': 'available'
        }
        
        # إنشاء الوحدة الأولى
        client.post('/api/v1/units', json=unit_data, headers=auth_headers)
        
        # محاولة إنشاء وحدة أخرى بنفس الرقم
        response = client.post('/api/v1/units', 
                             json=unit_data, 
                             headers=auth_headers)
        data = response.get_json()
        
        assert response.status_code == 400
        assert data['success'] is False
        assert 'موجود بالفعل' in data['message']
    
    def test_get_unit_stats(self, client, auth_headers):
        """اختبار الحصول على إحصائيات الوحدات"""
        response = client.get('/api/v1/units/stats', headers=auth_headers)
        data = response.get_json()
        
        assert response.status_code == 200
        assert data['success'] is True
        assert 'stats' in data
        assert 'total_units' in data['stats']
        assert 'occupied_units' in data['stats']
        assert 'available_units' in data['stats']
        assert 'maintenance_units' in data['stats']

class TestHealthCheck:
    """اختبارات فحص صحة النظام"""
    
    def test_health_check_success(self, client):
        """اختبار فحص صحة النظام"""
        response = client.get('/api/v1/health')
        data = response.get_json()
        
        assert response.status_code == 200
        assert data['success'] is True
        assert data['message'] == 'API is running'
        assert 'timestamp' in data

class TestSecurityFeatures:
    """اختبارات ميزات الأمان"""
    
    def test_rate_limiting(self, client):
        """اختبار تحديد معدل الطلبات"""
        # إرسال طلبات متعددة للتحقق من Rate Limiting
        for i in range(12):  # أكثر من الحد المسموح (10 في الدقيقة)
            response = client.get('/api/v1/health')
        
        # الطلب الأخير يجب أن يكون محدود
        assert response.status_code == 429
    
    def test_security_headers(self, client):
        """اختبار وجود Security Headers"""
        response = client.get('/')
        
        # التحقق من وجود Security Headers
        assert 'X-Frame-Options' in response.headers
        assert 'X-Content-Type-Options' in response.headers
        assert 'Strict-Transport-Security' in response.headers
    
    def test_csrf_protection(self, client):
        """اختبار حماية CSRF"""
        # محاولة إرسال طلب POST بدون CSRF token
        response = client.post('/api/v1/auth/register', json={
            'email': 'test@example.com',
            'password': 'password123'
        })
        
        # يجب أن يكون الطلب ناجح لأن API endpoints معفاة من CSRF
        # ولكن الصفحات العادية محمية
        assert response.status_code in [200, 201, 400]  # ليس 403 (CSRF error)

class TestErrorHandling:
    """اختبارات معالجة الأخطاء"""
    
    def test_404_error(self, client):
        """اختبار خطأ 404"""
        response = client.get('/api/v1/nonexistent')
        data = response.get_json()
        
        assert response.status_code == 404
        assert data['success'] is False
        assert data['message'] == 'المورد غير موجود'
    
    def test_405_method_not_allowed(self, client):
        """اختبار خطأ 405 - طريقة غير مسموحة"""
        response = client.delete('/api/v1/health')  # GET only endpoint
        data = response.get_json()
        
        assert response.status_code == 405
    
    def test_invalid_json(self, client):
        """اختبار إرسال JSON غير صحيح"""
        response = client.post('/api/v1/auth/register', 
                             data='invalid json',
                             content_type='application/json')
        
        assert response.status_code == 400

if __name__ == '__main__':
    pytest.main(['-v', '--cov=src', '--cov-report=html', '--cov-report=term'])

