import { describe, it, expect, vi, beforeEach } from 'vitest'
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import '@testing-library/jest-dom'
import App from '../src/App'

// Mock localStorage
const localStorageMock = {
  getItem: vi.fn(),
  setItem: vi.fn(),
  removeItem: vi.fn(),
  clear: vi.fn(),
}
global.localStorage = localStorageMock

describe('App Component', () => {
  beforeEach(() => {
    localStorageMock.getItem.mockClear()
    localStorageMock.setItem.mockClear()
    localStorageMock.removeItem.mockClear()
  })

  it('renders the main dashboard', () => {
    render(<App />)
    
    // التحقق من وجود العناصر الأساسية
    expect(screen.getByText('لوحة التحكم الرئيسية')).toBeInTheDocument()
    expect(screen.getByText('نظام إدارة المول الذكي')).toBeInTheDocument()
  })

  it('displays language switcher', () => {
    render(<App />)
    
    // التحقق من وجود مبدل اللغة
    const languageSwitcher = screen.getByRole('button', { name: /العربية|English/ })
    expect(languageSwitcher).toBeInTheDocument()
  })

  it('switches language when language button is clicked', async () => {
    render(<App />)
    
    const languageButton = screen.getByRole('button', { name: /العربية|English/ })
    
    // النقر على مبدل اللغة
    fireEvent.click(languageButton)
    
    await waitFor(() => {
      // التحقق من تغيير اللغة
      expect(screen.getByText(/Dashboard|لوحة التحكم/)).toBeInTheDocument()
    })
  })

  it('saves language preference to localStorage', () => {
    render(<App />)
    
    const languageButton = screen.getByRole('button', { name: /العربية|English/ })
    fireEvent.click(languageButton)
    
    // التحقق من حفظ تفضيل اللغة
    expect(localStorageMock.setItem).toHaveBeenCalledWith('language', expect.any(String))
  })

  it('loads language preference from localStorage', () => {
    localStorageMock.getItem.mockReturnValue('en')
    
    render(<App />)
    
    // التحقق من تحميل تفضيل اللغة
    expect(localStorageMock.getItem).toHaveBeenCalledWith('language')
  })

  it('displays statistics cards', () => {
    render(<App />)
    
    // التحقق من وجود بطاقات الإحصائيات
    expect(screen.getByText(/إجمالي الوحدات|Total Units/)).toBeInTheDocument()
    expect(screen.getByText(/الوحدات المشغولة|Occupied Units/)).toBeInTheDocument()
    expect(screen.getByText(/الوحدات المتاحة|Available Units/)).toBeInTheDocument()
    expect(screen.getByText(/طلبات الصيانة|Maintenance Requests/)).toBeInTheDocument()
  })

  it('displays navigation sidebar', () => {
    render(<App />)
    
    // التحقق من وجود الشريط الجانبي
    expect(screen.getByText(/لوحة التحكم|Dashboard/)).toBeInTheDocument()
    expect(screen.getByText(/الوحدات|Units/)).toBeInTheDocument()
    expect(screen.getByText(/المستأجرين|Tenants/)).toBeInTheDocument()
    expect(screen.getByText(/الصيانة|Maintenance/)).toBeInTheDocument()
  })

  it('displays quick actions section', () => {
    render(<App />)
    
    // التحقق من وجود قسم الإجراءات السريعة
    expect(screen.getByText(/إضافة وحدة جديدة|Add New Unit/)).toBeInTheDocument()
    expect(screen.getByText(/إضافة مستأجر|Add Tenant/)).toBeInTheDocument()
    expect(screen.getByText(/طلب صيانة|Maintenance Request/)).toBeInTheDocument()
  })

  it('displays recent activities', () => {
    render(<App />)
    
    // التحقق من وجود قسم الأنشطة الحديثة
    expect(screen.getByText(/الأنشطة الحديثة|Recent Activities/)).toBeInTheDocument()
  })

  it('handles responsive design', () => {
    // محاكاة شاشة صغيرة
    Object.defineProperty(window, 'innerWidth', {
      writable: true,
      configurable: true,
      value: 768,
    })
    
    render(<App />)
    
    // التحقق من التصميم المتجاوب
    const sidebar = screen.getByRole('navigation')
    expect(sidebar).toBeInTheDocument()
  })

  it('displays correct RTL/LTR direction based on language', () => {
    const { container } = render(<App />)
    
    // التحقق من اتجاه النص للعربية (RTL)
    expect(container.firstChild).toHaveAttribute('dir', 'rtl')
    
    // تغيير اللغة إلى الإنجليزية
    const languageButton = screen.getByRole('button', { name: /العربية/ })
    fireEvent.click(languageButton)
    
    // التحقق من اتجاه النص للإنجليزية (LTR)
    expect(container.firstChild).toHaveAttribute('dir', 'ltr')
  })
})

describe('Language System', () => {
  it('provides correct translations for Arabic', () => {
    localStorageMock.getItem.mockReturnValue('ar')
    
    render(<App />)
    
    expect(screen.getByText('لوحة التحكم الرئيسية')).toBeInTheDocument()
    expect(screen.getByText('نظام إدارة المول الذكي')).toBeInTheDocument()
    expect(screen.getByText('إجمالي الوحدات')).toBeInTheDocument()
  })

  it('provides correct translations for English', () => {
    localStorageMock.getItem.mockReturnValue('en')
    
    render(<App />)
    
    expect(screen.getByText('Main Dashboard')).toBeInTheDocument()
    expect(screen.getByText('Smart Mall Management System')).toBeInTheDocument()
    expect(screen.getByText('Total Units')).toBeInTheDocument()
  })

  it('falls back to Arabic when no language preference is set', () => {
    localStorageMock.getItem.mockReturnValue(null)
    
    render(<App />)
    
    expect(screen.getByText('لوحة التحكم الرئيسية')).toBeInTheDocument()
  })
})

describe('Statistics Display', () => {
  it('displays statistics with correct formatting', () => {
    render(<App />)
    
    // التحقق من تنسيق الأرقام
    const totalUnits = screen.getByText('150')
    const occupiedUnits = screen.getByText('120')
    const availableUnits = screen.getByText('30')
    const maintenanceRequests = screen.getByText('8')
    
    expect(totalUnits).toBeInTheDocument()
    expect(occupiedUnits).toBeInTheDocument()
    expect(availableUnits).toBeInTheDocument()
    expect(maintenanceRequests).toBeInTheDocument()
  })

  it('displays trend indicators', () => {
    render(<App />)
    
    // التحقق من وجود مؤشرات الاتجاه
    const trendIndicators = screen.getAllByText(/↗|↘|→/)
    expect(trendIndicators.length).toBeGreaterThan(0)
  })
})

describe('User Interface Interactions', () => {
  it('handles sidebar navigation clicks', () => {
    render(<App />)
    
    const unitsLink = screen.getByText(/الوحدات|Units/)
    fireEvent.click(unitsLink)
    
    // التحقق من تفاعل التنقل
    expect(unitsLink).toHaveClass('active')
  })

  it('handles quick action button clicks', () => {
    render(<App />)
    
    const addUnitButton = screen.getByText(/إضافة وحدة جديدة|Add New Unit/)
    fireEvent.click(addUnitButton)
    
    // التحقق من تفاعل الأزرار
    expect(addUnitButton).toBeInTheDocument()
  })

  it('displays notifications correctly', () => {
    render(<App />)
    
    // التحقق من وجود منطقة الإشعارات
    const notificationArea = screen.getByRole('button', { name: /إشعارات|Notifications/ })
    expect(notificationArea).toBeInTheDocument()
  })
})

describe('Accessibility', () => {
  it('has proper ARIA labels', () => {
    render(<App />)
    
    // التحقق من وجود ARIA labels
    const navigation = screen.getByRole('navigation')
    const main = screen.getByRole('main')
    
    expect(navigation).toBeInTheDocument()
    expect(main).toBeInTheDocument()
  })

  it('supports keyboard navigation', () => {
    render(<App />)
    
    const languageButton = screen.getByRole('button', { name: /العربية|English/ })
    
    // محاكاة التنقل بالكيبورد
    languageButton.focus()
    expect(languageButton).toHaveFocus()
    
    fireEvent.keyDown(languageButton, { key: 'Enter' })
    // التحقق من استجابة الكيبورد
  })

  it('has proper heading hierarchy', () => {
    render(<App />)
    
    // التحقق من تسلسل العناوين
    const h1 = screen.getByRole('heading', { level: 1 })
    const h2Elements = screen.getAllByRole('heading', { level: 2 })
    
    expect(h1).toBeInTheDocument()
    expect(h2Elements.length).toBeGreaterThan(0)
  })
})

