import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { 
  Building2, 
  Users, 
  Wrench, 
  FileText, 
  DollarSign, 
  BarChart3,
  Settings,
  Bell,
  Search,
  Plus,
  Home,
  Languages,
  Menu,
  X
} from 'lucide-react';
import './App.css';

// Language context
const LanguageContext = React.createContext();

// Translation data
const translations = {
  ar: {
    appTitle: 'تطبيق إدارة المول الذكي',
    dashboard: 'لوحة التحكم',
    units: 'الوحدات',
    tenants: 'المستأجرين',
    maintenance: 'طلبات الصيانة',
    permits: 'التصاريح',
    invoices: 'الفواتير',
    reports: 'التقارير',
    settings: 'الإعدادات',
    occupancyRate: 'معدل الإشغال',
    totalUnits: 'إجمالي الوحدات',
    maintenanceRequests: 'طلبات الصيانة',
    pendingPermits: 'التصاريح المعلقة',
    recentActivities: 'الأنشطة الحديثة',
    quickActions: 'إجراءات سريعة',
    addUnit: 'إضافة وحدة',
    addTenant: 'إضافة مستأجر',
    newMaintenance: 'طلب صيانة جديد',
    newPermit: 'تصريح جديد',
    search: 'بحث...',
    notifications: 'الإشعارات',
    profile: 'الملف الشخصي',
    logout: 'تسجيل الخروج',
    welcome: 'مرحباً بك في نظام إدارة المول الذكي',
    description: 'نظام شامل لإدارة المولات التجارية والإدارية بكفاءة عالية',
    language: 'اللغة',
    arabic: 'العربية',
    english: 'English'
  },
  en: {
    appTitle: 'Smart Mall Management System',
    dashboard: 'Dashboard',
    units: 'Units',
    tenants: 'Tenants',
    maintenance: 'Maintenance',
    permits: 'Permits',
    invoices: 'Invoices',
    reports: 'Reports',
    settings: 'Settings',
    occupancyRate: 'Occupancy Rate',
    totalUnits: 'Total Units',
    maintenanceRequests: 'Maintenance Requests',
    pendingPermits: 'Pending Permits',
    recentActivities: 'Recent Activities',
    quickActions: 'Quick Actions',
    addUnit: 'Add Unit',
    addTenant: 'Add Tenant',
    newMaintenance: 'New Maintenance Request',
    newPermit: 'New Permit',
    search: 'Search...',
    notifications: 'Notifications',
    profile: 'Profile',
    logout: 'Logout',
    welcome: 'Welcome to Smart Mall Management System',
    description: 'Comprehensive system for efficient management of commercial and administrative malls',
    language: 'Language',
    arabic: 'العربية',
    english: 'English'
  }
};

// Language Hook
const useLanguage = () => {
  const [language, setLanguage] = useState('ar');
  const [direction, setDirection] = useState('rtl');

  const changeLanguage = (newLang) => {
    setLanguage(newLang);
    setDirection(newLang === 'ar' ? 'rtl' : 'ltr');
    document.documentElement.lang = newLang;
    document.documentElement.dir = newLang === 'ar' ? 'rtl' : 'ltr';
    localStorage.setItem('language', newLang);
  };

  const t = (key) => {
    return translations[language][key] || key;
  };

  useEffect(() => {
    const savedLang = localStorage.getItem('language') || 'ar';
    changeLanguage(savedLang);
  }, []);

  return { language, direction, changeLanguage, t };
};

// Language Switcher Component
const LanguageSwitcher = ({ language, changeLanguage, t }) => {
  return (
    <div className="flex items-center gap-2">
      <Languages className="h-4 w-4" />
      <Button
        variant="ghost"
        size="sm"
        onClick={() => changeLanguage(language === 'ar' ? 'en' : 'ar')}
        className="text-sm"
      >
        {language === 'ar' ? 'English' : 'العربية'}
      </Button>
    </div>
  );
};

// Sidebar Component
const Sidebar = ({ isOpen, onClose, language, t }) => {
  const menuItems = [
    { icon: Home, label: t('dashboard'), active: true },
    { icon: Building2, label: t('units') },
    { icon: Users, label: t('tenants') },
    { icon: Wrench, label: t('maintenance') },
    { icon: FileText, label: t('permits') },
    { icon: DollarSign, label: t('invoices') },
    { icon: BarChart3, label: t('reports') },
    { icon: Settings, label: t('settings') },
  ];

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div className={`
        fixed top-0 ${language === 'ar' ? 'right-0' : 'left-0'} h-full w-64 bg-card border-r border-border z-50
        transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : language === 'ar' ? 'translate-x-full' : '-translate-x-full'}
        lg:translate-x-0 lg:static lg:z-auto
      `}>
        <div className="p-6">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-xl font-bold text-primary">{t('appTitle')}</h2>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="lg:hidden"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          
          <nav className="space-y-2">
            {menuItems.map((item, index) => (
              <Button
                key={index}
                variant={item.active ? "default" : "ghost"}
                className={`w-full justify-start gap-3 ${language === 'ar' ? 'flex-row-reverse' : ''}`}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </Button>
            ))}
          </nav>
        </div>
      </div>
    </>
  );
};

// Header Component
const Header = ({ onMenuClick, language, changeLanguage, t }) => {
  return (
    <header className="bg-card border-b border-border px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={onMenuClick}
            className="lg:hidden"
          >
            <Menu className="h-4 w-4" />
          </Button>
          
          <div className="relative">
            <Search className={`absolute top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground ${
              language === 'ar' ? 'right-3' : 'left-3'
            }`} />
            <input
              type="text"
              placeholder={t('search')}
              className={`w-64 h-10 bg-muted rounded-md border border-border focus:outline-none focus:ring-2 focus:ring-primary ${
                language === 'ar' ? 'pr-10 text-right' : 'pl-10'
              }`}
            />
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <LanguageSwitcher language={language} changeLanguage={changeLanguage} t={t} />
          
          <Button variant="ghost" size="sm">
            <Bell className="h-4 w-4" />
          </Button>
          
          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
            <span className="text-primary-foreground text-sm font-medium">أ</span>
          </div>
        </div>
      </div>
    </header>
  );
};

// Stats Card Component
const StatsCard = ({ icon: Icon, title, value, color, trend }) => {
  return (
    <Card className="animate-fade-in-up">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold">{value}</p>
            {trend && (
              <p className="text-xs text-green-600 mt-1">
                ↗ {trend}
              </p>
            )}
          </div>
          <div className={`p-3 rounded-full ${color}`}>
            <Icon className="h-6 w-6 text-white" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

// Quick Actions Component
const QuickActions = ({ t }) => {
  const actions = [
    { icon: Plus, label: t('addUnit'), color: 'bg-blue-500' },
    { icon: Users, label: t('addTenant'), color: 'bg-green-500' },
    { icon: Wrench, label: t('newMaintenance'), color: 'bg-orange-500' },
    { icon: FileText, label: t('newPermit'), color: 'bg-purple-500' },
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t('quickActions')}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          {actions.map((action, index) => (
            <Button
              key={index}
              variant="outline"
              className="h-20 flex flex-col gap-2"
            >
              <div className={`p-2 rounded-full ${action.color}`}>
                <action.icon className="h-4 w-4 text-white" />
              </div>
              <span className="text-sm">{action.label}</span>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

// Recent Activities Component
const RecentActivities = ({ t }) => {
  const activities = [
    { type: 'maintenance', message: 'تم إنجاز طلب صيانة في الوحدة A-101', time: 'منذ ساعتين' },
    { type: 'permit', message: 'تم الموافقة على تصريح التجهيز للوحدة B-205', time: 'منذ 3 ساعات' },
    { type: 'tenant', message: 'تم إضافة مستأجر جديد للوحدة C-301', time: 'منذ يوم واحد' },
    { type: 'invoice', message: 'تم إنشاء فاتورة جديدة للمستأجر أحمد محمد', time: 'منذ يومين' },
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t('recentActivities')}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity, index) => (
            <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
              <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
              <div className="flex-1">
                <p className="text-sm">{activity.message}</p>
                <p className="text-xs text-muted-foreground mt-1">{activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

// Main Dashboard Component
const Dashboard = ({ t }) => {
  const stats = [
    { icon: Building2, title: t('occupancyRate'), value: '92%', color: 'bg-blue-500', trend: '+5%' },
    { icon: Home, title: t('totalUnits'), value: '100', color: 'bg-green-500', trend: '+2' },
    { icon: Wrench, title: t('maintenanceRequests'), value: '25', color: 'bg-orange-500' },
    { icon: FileText, title: t('pendingPermits'), value: '8', color: 'bg-purple-500' },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Welcome Section */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">{t('welcome')}</h1>
        <p className="text-muted-foreground">{t('description')}</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <StatsCard key={index} {...stat} />
        ))}
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <QuickActions t={t} />
        </div>
        <div className="lg:col-span-2">
          <RecentActivities t={t} />
        </div>
      </div>
    </div>
  );
};

// Main App Component
function App() {
  const { language, direction, changeLanguage, t } = useLanguage();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <LanguageContext.Provider value={{ language, direction, changeLanguage, t }}>
      <div className={`min-h-screen bg-background ${direction === 'rtl' ? 'arabic-text' : 'english-text'}`}>
        <div className="flex">
          <Sidebar 
            isOpen={sidebarOpen} 
            onClose={() => setSidebarOpen(false)}
            language={language}
            t={t}
          />
          
          <div className="flex-1 lg:mr-64">
            <Header 
              onMenuClick={() => setSidebarOpen(true)}
              language={language}
              changeLanguage={changeLanguage}
              t={t}
            />
            
            <main>
              <Dashboard t={t} />
            </main>
          </div>
        </div>
      </div>
    </LanguageContext.Provider>
  );
}

export default App;

